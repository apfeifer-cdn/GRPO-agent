# factory-invoice-to-opdn

Skill + reference script that turns a factory shipment's documents into an SAP B1 GRPO upload
workbook. Start at `SKILL.md`.

```
scripts/build_opdn.py        parser, grouping, lookup resolution, validation (bundled xlrd/ for .xls)
scripts/make_column_defaults.py  regenerates references/opdn-column-defaults.csv from the template
references/                  document anatomy, field mapping, validation rules, PO lookup export
examples/OPDN_Excel_template.xlsx   column layout for OPDN_Header / PDN1_Line
examples/OPDN_upload_BDA26091160.xlsx   output for the 4762 sea bundle (no lookup table)
examples/po_lookup_SAMPLE_fake_values.csv   lookup-table shape
```
Requires `openpyxl`; `pdfplumber` for PDF bundles.
Validated against 72 posted GRPOs (63 invoices, 494 lines): 0 MISMATCH, 493/494 lines resolved
to the posted PO line with a truth-derived lookup table.
