"""Factory shipping documents -> SAP B1 GRPO upload workbook (OPDN_Header / PDN1_Line).

Usage:
  python build_opdn.py <file-or-dir> [...] [--lookup po_lookup.xlsx|csv] [--post-date YYYY-MM-DD]
                       [--out out_dir] [--template OPDN_Excel_template.xlsx] [--invoice BDAnnnnnnnn] [--emit-csv]

Inputs (any mix; grouped by the Mainland invoice number BDAnnnnnnnn found in the file name or content):
  Mainland commercial invoice  <BDA> INVOICE <seq>.xlsx  or  <BDA> -<seq>.pdf (invoice + packing list in one PDF)
  Mainland packing list        <BDA> PACKING LIST <seq>.XLS (preferred line source) or the packing-list page(s) of the PDF
  Unimas factory workbook      Invoice & Packing List - <seq> (...).xls   (EX/UNI/<seq>/<yyyy>; cross-check and customer refs)
  First Sales invoice          First Sales <BDA>.xls / .pdf  (TH-<BDA>, Trend Hero)  -> U_FirstSalePrice / U_FirstSaleTotal
  House bill / shipment advice DML-nnnnnDRAFT.pdf, PSA_DML-....pdf, SA DRI Caps ... .xlsx -> container, seal, HBL, MBL, vessel, on-board date
One workbook per Mainland invoice. GRPOs per invoice: SPO/VAC lines and all other lines are posted separately when both exist.
One GRPO line per PO line: packing rows with the same PO + PI# + SEQ PI# + colour are summed.
Lookups (BaseEntry/BaseLine/Price/CardCode) come from the PO export (--lookup); otherwise LOOKUP:<key> placeholders.
Prints '=== GRPO SUMMARY ===' to stdout; relay it verbatim.
"""
import re, sys, os, csv, io, datetime as dt
from collections import OrderedDict, defaultdict
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)  # bundled xlrd
import xlrd, openpyxl

NULL = "NULL"
STOCK_PREFIXES = {"SPO", "VAC"}          # matrix/stock programs; posted on their own GRPO
DEFAULT_WHS = "2"                         # every example GRPO line
KG_TO_LB, CM_TO_IN = 2.20462, 1 / 2.54
BDA_RE = re.compile(r"\b(BDA\d{8})\b")
EXUNI_RE = re.compile(r"EX/UNI/(\d{3,5})/(\d{4})")
AIRLINES = {"ET": "ETHIOPIAN AIRLINES", "BA": "BRITISH AIRWAYS", "TK": "TURKISH AIRLINES", "SQ": "SINGAPORE AIRLINES", "EK": "EMIRATES", "QR": "QATAR AIRWAYS"}

# ---------------------------------------------------------------- helpers
def num(v):
    if v in (None, "", NULL): return None
    if isinstance(v, bool): return None
    if isinstance(v, (int, float)): return float(v)
    if isinstance(v, dt.datetime):
        from openpyxl.utils.datetime import to_excel
        return float(to_excel(v))
    try: return float(str(v).replace(",", "").strip())
    except ValueError: return None

def intq(v):
    f = num(v); return int(round(f)) if f is not None else None

def to_date(v):
    """DD.MM.YYYY, YYYY-MM-DD, YYYY/MM/DD, DD-MON-YY(YY), Excel serial, datetime -> date"""
    if isinstance(v, dt.datetime): return v.date()
    if isinstance(v, dt.date): return v
    if isinstance(v, (int, float)) and 30000 < v < 70000:
        return (dt.datetime(1899, 12, 30) + dt.timedelta(days=int(v))).date()
    s = str(v or "")
    m = re.search(r"(\d{2})\.(\d{2})\.(\d{4})", s)
    if m: return dt.date(int(m[3]), int(m[2]), int(m[1]))
    m = re.search(r"(\d{4})[-/](\d{2})[-/](\d{2})", s)
    if m: return dt.date(int(m[1]), int(m[2]), int(m[3]))
    m = re.search(r"(\d{2})-([A-Za-z]{3})-(\d{2,4})", s)
    if m:
        y = int(m[3]); y = y + 2000 if y < 100 else y
        return dt.date(y, dt.datetime.strptime(m[2].title(), "%b").month, int(m[1]))
    return None

def clean(s): return " ".join(str(s or "").replace("\n", " ").split())

def parse_po(s):
    """'SPO120599  91690' -> ('SPO', 120599, '91690'); Mainland lists omit the customer ref"""
    s = clean(s)
    m = re.match(r"^([A-Z0-9]{3})\s?(\d{6})\s*(.*)$", s)
    return (m[1], int(m[2]), m[3].strip() or None) if m else (None, None, s or None)

def color_key(c):
    k = re.sub(r"[\s/\-.]", "", str(c or "")).upper()
    return "" if k == NULL else k.replace("GREY", "GRAY")

def parse_style(style, color):
    """(item key, paren text, colour).
    'C17-06417(SP500)'        -> C17-06417, SP500
    'C26-05627-Navy'          -> C26-05627, colour Navy (air/PDF format: item-colour, no parens)
    'DON-1850MB-345-OS'       -> as printed (customer item code)
    '#83200TM(1850MB-997-OS)' -> 83200TM, 1850MB-997-OS"""
    s = clean(style); color = clean(color)
    m = re.match(r"^([^()]+?)\s*(?:\((.+)\))?$", s)
    base, par = (m[1].strip(), (m[2] or "").strip() or None) if m else (s, None)
    m2 = re.match(r"^(C\d{1,2}-\d{3,5}[A-Z]?)-\s*(.+)$", base, re.I)
    if m2 and not par:
        base, suffix = m2[1], m2[2].strip()
        ck, sk = color_key(color), color_key(suffix)
        if not color or ck == sk or (sk and sk in ck) or (ck and ck in sk) or len(color) > 40:
            color = suffix  # colour cell empty or garbled by PDF text wrap: the style suffix is authoritative
    return base.lstrip("#"), par, color

def rows_of(path):
    """Yield (sheet name, rows as lists) for .xls/.xlsx"""
    if path.lower().endswith(".xls"):
        wb = xlrd.open_workbook(path)
        for sh in wb.sheets():
            yield sh.name, [[sh.cell_value(r, c) for c in range(sh.ncols)] for r in range(sh.nrows)]
    else:
        wb = openpyxl.load_workbook(path, data_only=True)
        for ws in wb.worksheets:
            yield ws.title, [list(r) for r in ws.iter_rows(values_only=True)]

def pdf_pages(path):
    try: import pdfplumber
    except ImportError: sys.exit("pdfplumber is required to read PDF shipping documents: pip install pdfplumber")
    with pdfplumber.open(path) as pdf:
        return [(pg.extract_text() or "", pg.extract_tables()) for pg in pdf.pages]

# ---------------------------------------------------------------- packing table (any layout)
PACK_COLS = {"CTNS": ("CTN(S)", "CTNS)"), "CTNE": ("CTN(E)", "CTNE)"), "CTN": ("CTN",), "QPC": ("QTY/CTN",),
             "PI": ("PI#",), "SEQ": ("SEQPI#",), "PO": ("PO#",), "STYLE": ("STYLE#",), "COLOR": ("COLOR", "COLOUR"),
             "DESC": ("DESCRIPTION",), "QTY": ("TOTALPCS", "QNTYPCS"), "GW": ("GW/CTN", "GW"), "NW": ("NW/CTN", "NW"),
             "TGW": ("TOTALGW",), "TNW": ("TOTALNW",), "L": ("LENGTH",), "W": ("WIDTH",), "H": ("HEIGHT",), "CBM": ("CBM",)}

def map_header(hdr):
    keys = [re.sub(r"[\s.]", "", str(h or "")).upper() for h in hdr]   # 'CTN. (S)' / 'CTN. S)' -> 'CTN(S)' / 'CTNS)'; 'G.W/CTN' -> 'GW/CTN'
    out = {}
    for name, alts in PACK_COLS.items():
        for i, k in enumerate(keys):
            if k in alts and i not in out.values():
                out[name] = i; break
    return out

def packing_row(vals, cm):
    g = lambda k: vals[cm[k]] if k in cm and cm[k] < len(vals) else None
    s, e, ctn, qty = intq(g("CTNS")), intq(g("CTNE")), intq(g("CTN")), intq(g("QTY"))
    if s is None or qty is None: return None
    pre, po, ref = parse_po(g("PO"))
    style = clean(g("STYLE"))
    if ref and re.fullmatch(r"C\d{0,2}", ref) and (style.startswith("-") or style[:1].isdigit()):
        style, ref = ref + style, None                      # PDF wrapped the style's first characters into the PO# cell
    elif ref and re.fullmatch(r"C\d{0,2}", ref): ref = None
    if po is None: ref = None
    item, par, color = parse_style(style, g("COLOR"))
    gw, nw = num(g("GW")) or 0.0, num(g("NW")) or 0.0
    tgw, tnw = num(g("TGW")), num(g("TNW"))
    e = e if e is not None else s; ctn = ctn or (e - s + 1)
    return dict(ctn_s=s, ctn_e=e, ctn=ctn, qty_ctn=intq(g("QPC")) or 0,
                pi=clean(g("PI")).replace(" ", ""), seq=intq(g("SEQ")), po_raw=clean(g("PO")), prefix=pre, po=po, custref=ref,
                style_raw=style, item=item, paren=par, color=color, desc=clean(g("DESC")), qty=qty,
                gw_ctn=gw, nw_ctn=nw, gw=tgw if tgw is not None else round(gw * ctn, 2), nw=tnw if tnw is not None else round(nw * ctn, 2),
                L=num(g("L")) or 0.0, W=num(g("W")) or 0.0, H=num(g("H")) or 0.0, cbm=num(g("CBM")) or 0.0)

def parse_totals_row(r, cm):
    """Totals row variants: blank first cell + numbers under the columns; 'Total PCS : 58260 | TOTAL CTN : 405 ...'; 'TOTAL: | 405 | CTN | 58260 | PCS | G.W: | 6825.98 ...'"""
    tot = {}
    if r[0] in (None, "") and "CTN" in cm and isinstance(r[cm["CTN"]], (int, float)):
        for k, key in (("CTN", "ctn"), ("QTY", "qty"), ("TGW", "gw"), ("TNW", "nw"), ("CBM", "cbm")):
            if k in cm and cm[k] < len(r) and isinstance(r[cm[k]], (int, float)): tot[key] = float(r[cm[k]])
        return tot
    vals = [x for x in r if x not in (None, "")]
    for i, x in enumerate(vals):
        nxt = vals[i + 1] if i + 1 < len(vals) else None
        if isinstance(x, str) and isinstance(nxt, (int, float)) and (x.strip().endswith(":") or x.strip().upper().startswith("TOTAL")):
            k = x.strip().rstrip(": ").upper().replace("TOTAL ", "")
            key = {"PCS": "qty", "CTN": "ctn", "G.W": "gw", "N.W": "nw", "CBM": "cbm", "TOTAL": "ctn"}.get(k)
            if key: tot[key] = float(nxt)
        if isinstance(x, (int, float)) and isinstance(nxt, str):
            k = nxt.strip().upper()
            if k.startswith("CTN"): tot["ctn"] = float(x)
            elif k.startswith("PCS"): tot["qty"] = float(x)
            elif k.startswith("CBM"): tot["cbm"] = float(x)
    return tot

def packing_from_rows(rows):
    """Find the 'CTN. (S)' header in a sheet; return dict(lines, totals, top) or None"""
    hi = next((i for i, r in enumerate(rows) if r and re.match(r"^\s*CTN\.?\s*\(?S\)?", str(r[0] or ""), re.I)
               and any("PO" in str(x or "").upper() for x in r)), None)
    if hi is None: return None
    cm = map_header(rows[hi]); lines, tot = [], {}
    for r in rows[hi + 1:]:
        if not any(x not in (None, "") for x in r): continue
        c0 = r[0]
        if isinstance(c0, (int, float)) or (isinstance(c0, str) and c0.strip().isdigit()):
            l = packing_row(r, cm)
            if l: lines.append(l)
            continue
        if any(isinstance(x, (int, float)) for x in r):
            tot = parse_totals_row(r, cm)
            if tot: break
    return dict(lines=lines, totals=tot, top=rows[:hi]) if lines else None

def packing_from_pdf(pages):
    lines, tot, seen = [], {}, set()
    for text, tables in pages:
        if "COMMERCIAL INVOICE" in text[:400] or "Weight Report" in text: continue
        for tb in tables:
            cm = None
            for r in tb:
                if r and re.match(r"^\s*CTN\.?\s*\(?S\)?", str(r[0] or ""), re.I):
                    cm = map_header(r); continue
                if cm and r and str(r[0] or "").strip().isdigit():
                    l = packing_row(r, cm)
                    if not l: continue
                    key = (l["ctn_s"], l["ctn_e"], l["pi"], l["seq"], l["qty"], l["po_raw"])
                    if key in seen: continue  # pdfplumber returns a wrapped row twice
                    seen.add(key); lines.append(l)
        m = re.search(r"TOTAL:\s*(\d+)\s*CTN\s*(\d+)\s*PCS\s*G\.W:\s*([\d.]+)\s*N\.W:\s*([\d.]+)\s*([\d.]+)\s*CBM", text)
        if m: tot = dict(ctn=float(m[1]), qty=float(m[2]), gw=float(m[3]), nw=float(m[4]), cbm=float(m[5]))
    return dict(lines=lines, totals=tot, top=[]) if lines else None

# ---------------------------------------------------------------- Mainland commercial invoice
def invoice_from_text(text):
    h = {}
    m = re.search(r"COMMERCIAL INVOICE\s+((?:TH-)?BDA\d{8})", text)
    if not m: return None
    h["no"] = m[1]
    m = re.search(re.escape(h["no"]) + r"\s+(\d{4}-\d{2}-\d{2})", text); h["date"] = to_date(m[1]) if m else None
    m = re.search(r"Sailing on or about:\s*(\d{4}-\d{2}-\d{2})", text); h["sail"] = to_date(m[1]) if m else None
    m = re.search(r"Factory INVOICE:\s*(EX/UNI/\d+/\d{4})", text); h["factory_inv"] = m[1] if m else None
    m = re.search(r"Shipping Method:\s*(\w+)", text); h["method"] = m[1] if m else None
    m = re.search(r"Carrier:\s*([A-Z][A-Z .&]+?)\s*(?:container is stuffed|Port of|\n|$)", text); h["carrier"] = clean(m[1]) if m else None
    m = re.search(r"Ship To Name and Address :.*?\n(.*?)\n(.*?)\n(.*?)\n", text, re.S); h["ship_to"] = [clean(x) for x in m.groups()] if m else []
    m = re.search(r"Shipper Name and Address:.*?\n(.*?)\n", text, re.S); h["shipper"] = re.sub(r"\s*(TH-)?BDA\d{8}.*$", "", clean(m[1])) if m else None
    m = re.search(r"GRAND TOTAL\s+([\d,]+)\s*PCS\s+([\d,.]+)", text); h["tot_qty"] = num(m[1]) if m else None; h["tot_amt"] = num(m[2]) if m else None
    m = re.search(r"Country\s*of\s*Origin:\s*([A-Z]+)", text); h["coo"] = m[1] if m else None
    lines = []
    for ln in text.split("\n"):
        m = re.match(r"^(BA\s?\d{7})\s+([A-Z0-9]{3}\d{6})\s+(.*?)(\d{4}\.\d{2}\.\d{4})\s*(.*?)\s*(\d+)(?:PCS)?\s+([\d.]+)\s+([\d,.]+)$", ln.strip())
        if m:
            pre, po, _ = parse_po(m[2])
            lines.append(dict(pi=m[1].replace(" ", ""), po=po, prefix=pre, hts=m[4], style=clean(m[5]), qty=num(m[6]), price=num(m[7]), amt=num(m[8])))
    h["lines"] = lines
    return h

def invoice_from_rows(rows):
    h = {"lines": []}
    nxt = lambda r, j: next((x for x in r[j + 1:] if x not in (None, "")), None)
    for i, r in enumerate(rows):
        for j, v in enumerate(r):
            if not isinstance(v, str): continue
            t = v.strip()
            if "COMMERCIAL INVOICE" in t:
                m = re.search(r"((?:TH-)?BDA\d{8})", t)
                if m: h["no"] = m[1]
            elif "Factory INVOICE" in t: h["factory_inv"] = clean(nxt(r, j))
            elif "Sailing on or about" in t: h["sail"] = to_date(t) or to_date(nxt(r, j))
            elif t.startswith("Shipping Method"):
                h["method"] = ((t.split(":", 1)[1].strip() or clean(nxt(r, j))).split() or [None])[0]
            elif t.startswith("Carrier"): h["carrier"] = clean(t.split(":", 1)[1]) or clean(nxt(r, j)) or None
            elif t.startswith("Shipper Name"): h["shipper"] = clean(rows[i + 1][j]) if i + 1 < len(rows) else None
            elif t.startswith("Ship To Name"): h["ship_to"] = [clean(rows[i + k][j]) for k in (1, 2, 3) if i + k < len(rows) and rows[i + k][j]]
            elif t.startswith("Country") and "Origin" in t:
                h["coo"] = clean(t.replace("\xa0", " ").split(":")[-1]) or clean(nxt(r, j))
            elif h.get("no") and t == h["no"].strip() and i < 15:
                d = next((to_date(x) for x in r[j + 1:] if to_date(x)), None)
                if d: h["date"] = d
            elif t.startswith("GRAND TOTAL"):
                nums = [x for x in r[j + 1:] if isinstance(x, (int, float))]
                if len(nums) >= 2: h["tot_qty"], h["tot_amt"] = float(nums[0]), float(nums[-1])
                elif nums: h["tot_amt"] = float(nums[-1])
                m = re.search(r"(\d+)\s*PCS", " ".join(str(x) for x in r if x))
                if m: h["tot_qty"] = num(m[1])
        if r and isinstance(r[0], str) and re.match(r"^BA\s?\d{7}$", r[0].strip()):
            vals = [x for x in r if x not in (None, "")]
            if len(vals) >= 7:
                pre, po, _ = parse_po(vals[1])
                h["lines"].append(dict(pi=vals[0].replace(" ", ""), po=po, prefix=pre, desc=clean(vals[2]), hts=str(vals[3]),
                                       style=clean(vals[4]), qty=num(vals[5]), price=num(vals[6]), amt=num(vals[7]) if len(vals) > 7 else None))
    return h if h.get("no") else None

# ---------------------------------------------------------------- Unimas workbook (EX/UNI)
def unimas_from_rows(sheets):
    inv = next((rows for name, rows in sheets if name.lower().startswith("inv")), None)
    pac = next((rows for name, rows in sheets if name.lower().startswith("pac")), None)
    if pac is None: return None
    p = packing_from_rows(pac)
    if not p: return None
    h = {"lines": p["lines"], "totals": p["totals"]}
    top = " | ".join(clean(x) for r in p["top"] for x in r if x not in (None, ""))
    m = EXUNI_RE.search(top); h["no"] = f"EX/UNI/{m[1]}/{m[2]}" if m else None
    m = re.search(r"DATE\s*:\s*([\d.]+)", top); h["date"] = to_date(m[1]) if m else None
    m = re.search(r"ICD\s+DATE\s*:\s*([\d.]+)", top); h["icd_date"] = to_date(m[1]) if m else None
    m = re.search(r"SHIP MODE\s*:\s*(\w+)", top); h["mode"] = m[1] if m else None
    m = re.search(r"PORT OF LOADING\s*:\s*([^|]+)", top); h["port_load"] = clean(m[1]) if m else None
    m = re.search(r"HS CODE\s*:\s*(\d+)", top); h["hs"] = m[1] if m else None
    if inv:
        for r in inv[:20]:
            for j, v in enumerate(r):
                t = clean(v)
                if t.startswith("EXP. No"): h["exp_no"] = clean(next((x for x in r[j + 1:] if x not in (None, "", ":")), ""))
                if t.startswith("Contract No"): h["contract"] = clean(next((x for x in r[j + 1:] if x not in (None, "", ":")), ""))
                if t.startswith("Package"): h["cartons"] = intq(next((x for x in r[j + 1:] if isinstance(x, (int, float))), None))
        for r in inv:
            for j, v in enumerate(r):
                if clean(v).startswith("Total G.W") and j + 1 < len(r): h["inv_gw"] = num(r[j + 1])
                if clean(v).startswith("Total N.W") and j + 1 < len(r): h["inv_nw"] = num(r[j + 1]); h["inv_pcs"] = num(r[j - 2])
    return h

# ---------------------------------------------------------------- transport documents
def transport_from_text(text, fname):
    t = {}
    m = re.search(r"INV(?:OICE)? NO\s*:?\s*(EX/UNI/\d+/\d{4})", text); t["factory_inv"] = m[1] if m else None
    m = re.search(r"B/L NUMBER.*?\n.*?(DML-\d+)", text, re.S) or re.search(r"HAWB NO\.\s*(DML-\d+)", text) or re.search(r"(DML-\d{5})", fname)
    t["hbl"] = m[1].replace("-", "") if m else None
    m = re.search(r"([A-Z]{4}\d{7})/(\w+)\s+SEAL:\s*(\w+)(?:\s+(\d+)\s+CARTONS\s+([\d.]+)\s*KGS\s+([\d.]+)\s*CBM)?", text)
    if m:
        t["container"], t["size"], t["seal"] = m[1], m[2], m[3]
        if m[4]: t["cartons"], t["gw"], t["cbm"] = int(m[4]), float(m[5]), float(m[6])
    m = re.search(r"SHIPPED ON BOARD[^\n]*\n(?:[^\n]*\n){0,2}?[^\n]*?(\d{2}-[A-Z]{3}-\d{4})", text); t["on_board"] = to_date(m[1]) if m else None
    m = re.search(r"MAWB NO\.\s*([\d][\d -]+?)\s+-?\s*HAWB", text); t["mawb"] = re.sub(r"\D", "", m[1]) if m else None
    ves = re.findall(r"\n([A-Z][A-Z ]{3,30}V-\w+)", text)
    if ves: t["vessel"] = ves[-1].strip()
    if "Air Waybill" in text:
        m = re.search(r"([A-Z]{2}-?\d{3,4})\s+(\d{2}-[A-Z]{3}-\d{2})", text)
        if m: t["flight"], t["flight_date"] = m[1], to_date(m[2])
    m = re.search(r"MBL No\.\s*(\w+)", text); t["mbl"] = m[1] if m else None
    m = re.search(r"2nd Vessel\s+([A-Z][A-Z ]+V-\w+)", text)
    if m: t["vessel"] = m[1].strip()
    for mm in re.finditer(r"([A-Z]{4}\d{7})\s+(\w+)\s+([A-Z0-9]+)\s+FOB\s+(DML-\d+)\s+\S+\s+(\d{2}-[A-Za-z]{3}-\d{2})\s+(\d+)\s+CARTONS\s+([\d.]+)\s+([\d.]+)", text):
        fi = EXUNI_RE.search(text[max(0, mm.start() - 200):mm.start()])
        t.setdefault("psa", []).append(dict(container=mm[1], size=mm[2], seal=mm[3], hbl=mm[4].replace("-", ""), stuffing=to_date(mm[5]),
                                           cartons=int(mm[6]), gw=float(mm[7]), cbm=float(mm[8]), factory_inv=f"EX/UNI/{fi[1]}/{fi[2]}" if fi else None,
                                           mbl=t.get("mbl"), vessel=t.get("vessel")))
    return t

def shipment_advice_from_rows(rows):
    adv = []
    txt = "\n".join(" ".join(clean(x) for x in r if x not in (None, "")) for r in rows)
    for r in rows:
        vals = [clean(x) for x in r]
        cont = next((v for v in vals if re.match(r"^[A-Z]{4}\d{7}$", v)), None)
        if not cont: continue
        fi = next((v for v in vals if EXUNI_RE.search(v)), None)
        hbl = next((v for v in vals if re.match(r"^DML-\d+$", v)), None)
        seal = next((v for v in vals if re.match(r"^BDA\d{6}$", v)), None)
        size = next((v for v in vals if re.match(r"^\d{2}'", v)), None)
        adv.append(dict(container=cont, factory_inv=fi, hbl=hbl.replace("-", "") if hbl else None, seal=seal, size=size))
    m = re.search(r"BL#\s*(\w+)", txt); mbl = m[1] if m else None
    m = re.search(r"Mother:\s*([A-Z][A-Z ]+V-\w+)", txt); ves = m[1].strip() if m else None
    for a in adv: a["mbl"], a["vessel"] = mbl, ves
    return adv

# ---------------------------------------------------------------- discovery
def first_sales_lines(rows):
    out = []
    for r in rows:
        if r and isinstance(r[0], str) and re.match(r"^BA\s?\d{7}$", r[0].strip()):
            vals = [x for x in r if x not in (None, "")]
            if len(vals) >= 7:
                out.append(dict(pi=vals[0].replace(" ", ""), po=parse_po(vals[1])[1], style=clean(vals[4]), qty=num(vals[5]), price=num(vals[6]), amt=num(vals[7]) if len(vals) > 7 else None))
    return out

def discover(paths):
    """Walk files; return (bundles by BDA, Unimas workbooks by EX/UNI no., transport docs)"""
    files = []
    for p in paths:
        if os.path.isdir(p):
            for dp, _, fn in os.walk(p): files += [os.path.join(dp, f) for f in fn]
        else: files.append(p)
    B = defaultdict(lambda: dict(inv=None, inv_src=None, pack=None, pack_src=None, fs=None, fs_src=None))
    unimas, transport = {}, []
    for f in sorted(files):
        name = os.path.basename(f); low = name.lower()
        try:
            if low.endswith((".xls", ".xlsx", ".xlsm")):
                sheets = list(rows_of(f))
                if any(n.lower().startswith("pac") for n, _ in sheets):
                    u = unimas_from_rows(sheets)
                    if u: u["src"] = name; unimas[u["no"]] = u; continue
                bda = BDA_RE.search(name)
                is_fs = "FIRST SALES" in name.upper() or "1ST SALES" in name.upper()
                if bda and is_fs:
                    fs = {"no": "TH-" + bda[1], "lines": []}
                    for n, rows in sheets: fs["lines"] += first_sales_lines(rows)
                    d = B[bda[1]]; d["fs"], d["fs_src"] = fs, name
                elif bda:
                    for n, rows in sheets:
                        p = packing_from_rows(rows)
                        if p and "PACKING" in name.upper():
                            d = B[bda[1]]; d["pack"], d["pack_src"] = p, name
                        inv = invoice_from_rows(rows)
                        if inv and not inv["no"].startswith("TH-"):
                            d = B[inv["no"]]; d["inv"], d["inv_src"] = inv, name
                elif "SHIPMENT ADVICE" in " ".join(n.upper() for n, _ in sheets) or low.startswith("sa "):
                    transport.append(dict(src=name, psa=shipment_advice_from_rows(sheets[0][1])))
            elif low.endswith(".pdf"):
                pages = pdf_pages(f); text = "\n".join(t for t, _ in pages)
                inv = invoice_from_text(text)
                if inv and inv["no"].startswith("TH-"):
                    d = B[inv["no"][3:]]
                    if not d["fs"]: d["fs"], d["fs_src"] = inv, name
                elif inv:
                    d = B[inv["no"]]
                    if not d["inv"]: d["inv"], d["inv_src"] = inv, name
                    p = packing_from_pdf(pages)
                    if p and not d["pack"]: d["pack"], d["pack_src"] = p, name
                elif "DML" in name.upper() or "PSA" in name.upper() or "SHIPMENT ADVICE" in text or "Air Waybill" in text:
                    t = transport_from_text(text, name); t["src"] = name; transport.append(t)
        except Exception as e:  # one unreadable attachment must not stop the batch
            transport.append(dict(src=name, error=repr(e)))
    return dict(B), unimas, transport

# ---------------------------------------------------------------- grouping + merging
def group_lines(lines):
    """Sum packing rows that belong to one PO line (PO + PI# + SEQ PI# + colour); split SPO/VAC from the rest."""
    merged = OrderedDict()
    for l in lines:
        k = (l["po"], l["pi"], l["seq"], color_key(l["color"]))
        if k in merged:
            m = merged[k]; m["rows"].append(l)
            m["qty"] += l["qty"]; m["ctn"] += l["ctn"]; m["gw"] = round(m["gw"] + l["gw"], 2); m["nw"] = round(m["nw"] + l["nw"], 2); m["cbm"] += l["cbm"]
            m["ctn_s"], m["ctn_e"] = min(m["ctn_s"], l["ctn_s"]), max(m["ctn_e"], l["ctn_e"])
            if l["qty_ctn"] > m["qty_ctn"]:
                m["qty_ctn"], m["gw_ctn"], m["nw_ctn"], m["L"], m["W"], m["H"] = l["qty_ctn"], l["gw_ctn"], l["nw_ctn"], l["L"], l["W"], l["H"]
        else:
            m = dict(l); m["rows"] = [l]; merged[k] = m
    for m in merged.values():
        m["packing"] = ", ".join(f"{r['ctn']}-{r['qty_ctn']}" for r in m["rows"])  # SAP U_Packing text: "3-144, 1-72"
        m["mixed"] = len(m["rows"]) > 1
    all_lines = list(merged.values())
    stock = [m for m in all_lines if m["prefix"] in STOCK_PREFIXES]
    other = [m for m in all_lines if m["prefix"] not in STOCK_PREFIXES]
    groups = [g for g in (stock, other) if g]
    for g in groups: g.sort(key=lambda m: (m["po"] or 0, m["seq"] or 0, m["ctn_s"]))  # SAP VisOrder: by PO, then PO line
    return groups

# ---------------------------------------------------------------- template + rows
def load_template(path):
    wb = openpyxl.load_workbook(path); out = {}
    for ws in wb.worksheets:
        hdr = [c.value for c in ws[1] if c.value is not None]
        out[ws.title] = (hdr, {h: ws.cell(2, i + 1).value for i, h in enumerate(hdr)})
    return out

SYSTEM_HDR = {"DocNum","TransId","DocTime","CreateDate","UpdateDate","CreateTS","UpdateTS","UserSign","UserSign2","StationID","FinncPriod",
    "LogInstanc","VersionNum","Instance","Ref1","ReceiptNum","OwnerCode","Max1099","DocTotal","DocTotalSy","DocTotalFC","PaidToDate","PaidSys",
    "PaidFC","ImportEnt","SumAbsId","LndCstNum","VatJENum","ReqType","CtlAccount","CntctCode","PayToCode","Series","GroupNum","PeyMethod",
    "Weight","Volume","U_ValidationMessage","U_ValidationTime","U_SalesforceID","U_SalesforceUpdated","U_ScannedOrder","U_SAPDocumentID",
    "U_OrigShipDt","U_RevShipDt","U_OrigDelivery","U_RevDelivery","U_QuotedDelivery","U_SONo","U_CustRefNo","U_ActManuf","U_SendSOA","U_SendSOADate",
    "U_ImpSchComm","U_UltDelivery","U_POType","U_Prepared","U_ShipInst","U_CustComm","U_SOAComm","U_Confirmed","U_ProdReady","U_Event","U_EventDt",
    "U_ImportAuthKey","U_SpecialTariff","U_FrtFwd","U_ShipNotif","U_RevDeliveryToUse","U_UltDeliveryToUse","U_EDI","U_A1WMS_OShipPayType",
    "U_A1WMS_OShipPayAcc","U_TrackComment","U_TrackLocation","U_TrkLocationDate","U_CLMComments","U_FFInvoiceDate","U_FrtFwdInv",
    "U_ETAPortOfArrival","U_InitialVesselETA","U_InitialGnosisRailETA","U_RailETADest","U_TransshipDate","U_BookingDate","U_FtyDcReqDt","U_FtyDcRcvdDt",
    "U_ActShipDt","U_CustEntryNo","U_CustEntryDt","U_CustClearDt","U_LCDutyActual","U_LCFreightActual","U_ArrivalDestPort","U_GroundedAtDestPort","U_PODUnloaded",
    "U_FirstUSPort","U_FirstUSPortArrivalDate","U_FirstUSPortDepartDate","U_ActualDelDate","U_PackListSent","U_ImpAuthOnFile","U_AssistValue"}
SYSTEM_LINE = {"TargetType","TrgetEntry","OpenQty","OpenSum","OpenSumFC","OpenSumSys","AcctCode","CogsAcct","FinncPriod","LogInstanc","OwnerCode",
    "DocDate","StockSum","StockSumSc","StckSumApp","StckAppSc","GTotal","GTotalSC","TotalSumSy","LineTotal","INMPrice","PriceBefDi","PriceAfVAT",
    "GPBefDisc","ShipToCode","ShipToDesc","BaseOpnQty","OpenInvQty","SlpCode","Volume","Weight1","VolUnit","U_Duty","U_MPF","U_BrokerFee","U_Freight",
    "U_LocalWH","U_QCFee","U_Insurance","U_Finance","U_FixedCharge","U_Incremental","U_Marketing","U_MiscDuty","U_LDP","U_DRIGM","U_AgentCommLDP",
    "U_MiscExp","U_DomHT","U_DRIGMLDP","U_KidLT","U_CamoRoyalty","U_CamoDuty","U_Cunsump","U_Rebate","U_AgentComm","U_SpecialTariff","U_SpecialTariffPct",
    "U_SpecialTariffActualPct","U_CustRetailPrice","U_CamoFabAssist","U_CamoAssistDuty","U_SalesforceID","U_SAPOrderLineID","U_SAPDocumentLineID",
    "U_LineProdStatus","U_LineUltDelivery","U_QuotedDelivery","U_RevDelivery","U_CustPOLine","U_ImportHeaderID","U_ImportLineID","U_ImportSource",
    "U_ImportSourceOrig","U_CalcPrice","U_OrigQuantity","U_ArtNo","U_UPC","U_Size","U_StMaster","CodeBars","VendorNum","OrigItem","Text","TreeType",
    "U_FOBPrice","Price","BaseEntry","BaseLine","U_BaseEntry","U_BaseLine","BaseCard","DescOW","ConsumeFCT","ReturnAct","LinePoPrss","U_ReOrder","U_CPSCEFileCpltd","U_ProdStatusBlockLine"}
OPEN_STATUS = {"DocStatus": "O", "InvntSttus": "O", "Printed": "N", "Posted": "N", "Confirmed": "Y", "CANCELED": "N"}
LEAN_HDR = ["DocEntry","CardCode","CardName","DocDate","DocDueDate","NumAtCard","U_FactoryInv","Comments","U_POPrefix","U_OrderNo","U_FOB","U_FCAAirport",
    "U_OceanDest","U_COO","U_TermSale","U_MOT","TrnspCode","U_ShipVia","U_Notify","U_NumCartons","U_GrossWeight","U_DimWeight","U_CubeMeters",
    "U_ContREfNo","U_SealRefNo","U_BOLNo","U_MasterBLNo","U_AWB","U_MAWBNo","U_VesselName","U_Carrier","U_FirstSaleTotal","U_BLConsig","U_GenConsig",
    "Address","Address2","_FactoryInv","_ShipTo","_Sources"]
LEAN_LINE = ["DocEntry","LineNum","BaseType","BaseRef","BaseEntry","BaseLine","ItemCode","_Proto","_StyleRef","Dscription","Quantity","Price","_InvoicePrice",
    "U_FirstSalePrice","WhsCode","U_Color","U_LinePOPrefix","U_CustPO","U_CartonNo","U_PcsPerCarton","U_NumfCart","U_Packing","U_CartonWeight","U_CartonLength",
    "U_CartonWidth","U_CartonHeight","CountryOrg","ShipDate","FreeTxt","_PI","_SEQ","_PackGWkg","_PackCBM"]

def header_row(ctx, g, docentry, hdr, ex):
    row = OrderedDict()
    for col in hdr:
        v = ex.get(col)
        if col in SYSTEM_HDR: v = NULL
        if col in OPEN_STATUS: v = OPEN_STATUS[col]
        row[col] = v
    inv, air, tr, vendor = ctx["inv"], ctx["air"], ctx["transport"], ctx["vendor"]
    pos = sorted({l["po"] for l in g if l["po"]})
    first = min(g, key=lambda l: l["po"] or 0)
    ctn = sum(l["ctn"] for l in g); cbm = round(sum(l["cbm"] for l in g), 2)
    gw = round(sum(l["gw"] for l in g), 2); nw = round(sum(l["nw"] for l in g), 2)
    row.update({
        "DocEntry": docentry, "DocDate": ctx["post_date"], "TaxDate": ctx["post_date"], "DocDueDate": ctx["ship_date"],
        "CardCode": vendor["code"], "CardName": vendor["name"], "Address": vendor["address"],
        "Address2": "KS USA", "NumAtCard": inv["no"], "U_FactoryInv": inv["no"],
        "Comments": "Based On Purchase Orders " + " ".join(f"{p}." for p in pos),
        "JrnlMemo": f"Goods Receipt PO - {vendor['code']}",
        "U_POPrefix": first["prefix"] or NULL, "U_OrderNo": first["po"] if len(pos) == 1 else NULL,
        "TrnspCode": 37 if air else 1,
        "U_FOB": "Dhaka, Bangladesh" if air else "Chittagong, Bangladesh",
        "U_FCAAirport": "Dhaka, Bangladesh" if air else NULL,
        "U_OceanDest": NULL if air else "Kansas City, KS",
        "U_BLConsig": "Design Resources, Inc.", "U_GenConsig": "Design Resources, Inc.",
        "U_COO": ctx["coo"], "U_TermSale": "FOB",
        "U_MOT": "Air - Collect" if air else (tr.get("size_label") or "LOOKUP:container_size"),
        "U_ShipVia": "AIR" if air else "Demotrans",
        "U_Notify": ("FedEx Courier" if ctx["courier"] else "Bestway") if air else "Bestway International",
        "U_NumCartons": ctn, "U_CubeMeters": cbm,
        "U_GrossWeight": gw if air else (round(gw / ctn, 2) if ctn else NULL),   # air: shipment totals; sea: per-carton figure (REVIEW)
        "U_DimWeight": nw if air else (round(nw / ctn, 2) if ctn else NULL),
        "U_ContREfNo": tr.get("container") or tr.get("hbl") or tr.get("tracking") or NULL,
        "U_SealRefNo": tr.get("seal") or NULL, "U_BOLNo": (tr.get("hbl") or NULL) if not air else NULL, "U_MasterBLNo": tr.get("mbl") or NULL,
        "U_AWB": (tr.get("hbl") or tr.get("tracking") or NULL) if air else NULL, "U_MAWBNo": tr.get("mawb") or NULL,
        "U_VesselName": tr.get("vessel") or (tr.get("flight") if air else None) or NULL,
        "U_Carrier": tr.get("carrier") or NULL,
        "U_HandoverDate": NULL, "U_MakerTerms": "CDN", "U_FirstSaleTotal": 0,
        "WeightUnit": 3, "VolUnit": 4, "U_PackListRemarks": NULL,
        "_FactoryInv": inv.get("factory_inv") or NULL, "_ShipTo": " / ".join(inv.get("ship_to") or []) or NULL,
        "_Sources": "; ".join(ctx["sources"]),
    })
    return row

def line_row(ctx, l, docentry, linenum, hdr, ex):
    row = OrderedDict()
    for col in hdr:
        v = ex.get(col)
        if col in SYSTEM_LINE: v = NULL
        if col in ("LineStatus", "InvntSttus"): v = "O"
        row[col] = v
    key = f"LOOKUP:PO{l['po']}[{l['item']}|{l['color']}]"
    stock = l["prefix"] in STOCK_PREFIXES
    row.update({
        "DocEntry": docentry, "LineNum": linenum, "VisOrder": linenum,
        "BaseType": 22, "U_BaseType": 22, "BaseRef": l["po"], "BaseDocNum": l["po"],
        "BaseEntry": key + ".DocEntry", "BaseLine": key + ".LineNum", "U_BaseEntry": key + ".DocEntry", "U_BaseLine": key + ".LineNum",
        "BaseCard": ctx["vendor"]["code"], "ItemCode": l["item"], "Dscription": l["desc"],
        "Quantity": l["qty"], "InvQty": l["qty"], "PackQty": l["qty"], "BaseQty": l["qty"],
        "ShipDate": ctx["ship_date"], "ActDelDate": ctx["post_date"],
        "Price": key + ".Price", "_InvoicePrice": l["inv_price"] if l.get("inv_price") is not None else NULL,
        "U_FirstSalePrice": l["fs_price"] if l.get("fs_price") is not None else 0,
        "Currency": "$", "WhsCode": DEFAULT_WHS, "CountryOrg": ctx["coo"], "TrnsCode": 37 if ctx["air"] else 1,
        "U_Color": l["color"] if stock else NULL, "U_LinePOPrefix": l["prefix"] or NULL, "U_CustPO": l["custref"] or NULL,
        "U_CartonNo": f"{l['ctn_s']}-{l['ctn_e']}" if l["ctn_e"] != l["ctn_s"] else str(l["ctn_s"]),
        "U_PcsPerCarton": l["qty_ctn"], "U_NumfCart": l["ctn"], "U_Packing": l["packing"] if l["mixed"] else NULL,
        "U_CartonWeight": round(l["gw_ctn"] * KG_TO_LB, 1), "U_CartonLength": round(l["L"] * CM_TO_IN, 1),
        "U_CartonWidth": round(l["W"] * CM_TO_IN, 1), "U_CartonHeight": round(l["H"] * CM_TO_IN, 1),
        "FreeTxt": f"PI {l['pi']} seq {l['seq']}; packing style {l['style_raw']}; color {l['color']}"
                   + (f"; cust ref {l['custref']}" if l["custref"] else "") + (f"; mixed packing {l['packing']}" if l["mixed"] else ""),
        "_Proto": l["item"], "_StyleRef": l["paren"] or NULL, "_PI": l["pi"], "_SEQ": l["seq"], "_PackGWkg": l["gw"], "_PackCBM": round(l["cbm"], 4),
    })
    return row

# ---------------------------------------------------------------- PO lookup (OPOR/POR1/OITM export)
def load_lookup(path):
    if path.lower().endswith(".csv"):
        rows = list(csv.DictReader(open(path, newline="", encoding="utf-8-sig")))
    else:
        ws = openpyxl.load_workbook(path, data_only=True).worksheets[0]
        hdr = [c.value for c in ws[1]]
        rows = [dict(zip(hdr, r)) for r in ws.iter_rows(min_row=2, values_only=True) if any(v is not None for v in r)]
    by_po_item, by_po_style, by_po_cnum, by_po_proto, by_po, by_po_styleid = (defaultdict(list) for _ in range(6))
    for r in rows:
        if r.get("ItemCode") in (None, "", NULL): continue
        po = int(float(r["PONum"])); item = str(r["ItemCode"]).strip()
        r["_po"], r["_item"] = po, item
        by_po[po].append(r); by_po_item[(po, item.upper())].append(r)
        by_po_style[(po, item.split("-")[0].upper())].append(r)
        if r.get("U_Proto") not in (None, "", NULL): by_po_proto[(po, str(r["U_Proto"]).strip().upper())].append(r)
        sid = next((r[k] for k in ("U_StyleId", "U_StyleID", "U_STYLEID") if r.get(k) not in (None, "", NULL)), None)
        if sid: by_po_styleid[(po, str(sid).strip().lstrip("#").upper())].append(r)
        m = re.match(r"^(C\d{1,2}-\d{3,5}[A-Z]?)-", item, re.I)
        if m: by_po_cnum[(po, m[1].upper())].append(r)
        m = re.match(r"^(C\d{1,2}-\d{3,5})[A-Z]$", item, re.I)  # revision letter: C24-10449A is also reachable as C24-10449
        if m: by_po_cnum[(po, m[1].upper())].append(r)
    exported = next((r.get("ExportedAt") for r in rows if r.get("ExportedAt")), None)
    return dict(item=by_po_item, style=by_po_style, cnum=by_po_cnum, proto=by_po_proto, po=by_po, styleid=by_po_styleid, exported=exported)

def color_hits(cands, ck):
    def seg(x):
        parts = x["_item"].split("-")
        return color_key(parts[-2]) if len(parts) >= 3 else ""
    exact = [x for x in cands if ck and (color_key(x.get("U_Color")) == ck or seg(x) == ck)]
    if exact or len(ck) < 3: return exact
    return [x for x in cands if ((uk := color_key(x.get("U_Color"))) and (ck in uk or uk in ck))
            or ((sg := seg(x)) and len(sg) >= 3 and (sg.startswith(ck) or ck.startswith(sg)))]

def pick(hits, l, label):
    """Several candidate PO lines: SEQ PI# (= PO LineNum + 1), then open qty, then ordered qty, then lowest line that covers."""
    hits = sorted(hits, key=lambda x: int(num(x["BaseLine"])))
    q = l["qty"]
    opts = ", ".join(f"line {int(num(x['BaseLine']))} {x['_item']} ordered {num(x.get('OrderedQty')) or 0:g} open {num(x.get('OpenQty')) or 0:g}" for x in hits)
    exact = [x for x in hits if abs((num(x.get("OpenQty")) or 0) - q) < 1e-6]
    if len(exact) == 1: return exact[0], "OK", ""
    if l.get("seq"):   # SEQ PI# = PO line number + 1 (315/317 custom lines, 145/176 stock lines in the examples)
        s = [x for x in (exact or hits) if int(num(x["BaseLine"])) == l["seq"] - 1]
        if len(s) == 1: return s[0], "OK", ""
    if len(exact) > 1: return exact[0], "REVIEW", f"{len(exact)} open lines for {label} on PO {l['po']} all with open qty {q:g} ({opts}); took line {int(num(exact[0]['BaseLine']))}"
    ordered = [x for x in hits if abs((num(x.get("OrderedQty")) or 0) - q) < 1e-6 and (num(x.get("OpenQty")) or 0) >= q - 1e-6]
    if ordered: return ordered[0], "REVIEW", f"{len(hits)} open lines for {label} on PO {l['po']} ({opts}); took line {int(num(ordered[0]['BaseLine']))} whose ordered qty equals {q:g}"
    covers = [x for x in hits if (num(x.get("OpenQty")) or 0) >= q - 1e-6]
    if covers: return covers[0], "REVIEW", f"{len(hits)} open lines for {label} on PO {l['po']}, none with qty {q:g} ({opts}); took lowest line that covers: {int(num(covers[0]['BaseLine']))}"
    return None, "MISMATCH", f"{len(hits)} open lines for {label} on PO {l['po']} but none covers {q:g} ({opts})"

def resolve(l, lk, exclude=()):
    """exclude: (BaseEntry, BaseLine) pairs already consumed by other packing rows of the same PO line group"""
    ck = color_key(l["color"]); po = l["po"]; item = l["item"].upper()
    state = {"r": None, "status": "OK", "note": ""}
    def try_set(cands, label):
        cands = [x for x in (cands or []) if (int(num(x["BaseEntry"])), int(num(x["BaseLine"]))) not in exclude]
        if not cands: return False
        hit = color_hits(cands, ck); blank = [x for x in cands if not color_key(x.get("U_Color"))]
        if len(hit) == 1: state["r"] = hit[0]
        elif len(hit) > 1: state["r"], state["status"], state["note"] = pick(hit, l, label)
        elif len(cands) == 1 and blank: state["r"] = cands[0]
        elif blank and len(blank) == len(cands): state["r"], state["status"], state["note"] = pick(blank, l, f"{label} (no colour on PO lines)")
        else:
            state.update(r=None, status="MISMATCH", note=f"PO {po} {label}: no open line in colour '{l['color']}'; open: {sorted(x['_item'] + ' ' + str(x.get('U_Color')) for x in cands)}")
        return True
    stripped = re.sub(r"^(C\d{1,2}-\d{3,5})[A-Z]$", r"\1", item)
    par = (l.get("paren") or "").lstrip("#").upper()
    for cands, label in ((lk["proto"].get((po, item)), f"proto {l['item']}"),
                         (lk["item"].get((po, item)), l["item"]),
                         (lk["cnum"].get((po, item)) or lk["cnum"].get((po, stripped)), f"C-number {l['item']}"),
                         (lk["styleid"].get((po, item)) or (lk["styleid"].get((po, par)) if par else None), f"style id {l['item']}"),
                         (lk["style"].get((po, par.split("-")[0].split(".")[0])) if par else None, f"style {l.get('paren')}")):
        if try_set(cands, label) and (state["r"] or state["status"] == "MISMATCH"): break
    if not state["r"] and state["status"] != "MISMATCH":  # customer item codes / matrix styles: SAP SKU starts with the packing item, or its style prefix contains the paren text
        po_lines = lk["po"].get(po, [])
        pfx = [x for x in po_lines if x["_item"].upper().startswith(item)] or [x for x in po_lines if item in x["_item"].upper()]
        par0 = par.split("-")[0].split(".")[0] if par else ""
        sty = [x for x in po_lines if par0 and (x["_item"].split("-")[0].upper().startswith(par0) or x["_item"].split("-")[0].upper().endswith(par0))]
        for cands, label in ((pfx, f"item prefix {l['item']}"), (sty, f"style {par}")):
            if try_set(cands, label) and (state["r"] or state["status"] == "MISMATCH"): break
    r = state["r"]
    if not r and state["status"] != "MISMATCH":
        po_lines = lk["po"].get(po, [])
        if len(po_lines) == 1 and (num(po_lines[0].get("OpenQty")) or 0) >= l["qty"] - 1e-6:
            r = po_lines[0]; state.update(r=r, status="REVIEW", note=f"no item match for {l['item']} {l['color']}; took the only open line on PO {po}: {r['_item']}")
        elif not po_lines: return None, "MISMATCH", f"PO {po} not found or not open"
        else: return None, "MISMATCH", f"PO line not found: PO {po} {l['item']} {l['color']}; open: {sorted(x['_item'] + ' ' + str(x.get('U_Color')) for x in po_lines)}"
    if not r: return None, state["status"], state["note"]
    if num(r.get("Price")) in (None, 0):
        state["status"] = "REVIEW" if state["status"] == "OK" else state["status"]; state["note"] = (state["note"] + "; " if state["note"] else "") + "PO price is zero/blank"
    return r, state["status"], state["note"]

def apply_lookup(lrow, r):
    be, bl = int(num(r["BaseEntry"])), int(num(r["BaseLine"]))
    lrow.update({"BaseEntry": be, "BaseLine": bl, "U_BaseEntry": be, "U_BaseLine": bl, "BaseCard": r["CardCode"],
                 "Price": num(r.get("Price")), "U_FOBPrice": num(r.get("U_FOBPrice")) if r.get("U_FOBPrice") not in (None, "") else NULL,
                 "WhsCode": r.get("WhsCode") or DEFAULT_WHS, "ItemCode": r["_item"]})
    if r.get("Dscription"): lrow["Dscription"] = r["Dscription"]
    lrow["U_Color"] = r["U_Color"] if r.get("U_Color") not in (None, "", NULL) else NULL   # SAP: colour only where the PO line carries one
    if r.get("U_CustRefNo") not in (None, "", NULL): lrow["U_CustPO"] = r["U_CustRefNo"]
    lrow["LineTotal"] = round(lrow["Quantity"] * (lrow["Price"] or 0), 4)

# ---------------------------------------------------------------- build one Mainland invoice
def build_invoice(bda, d, unimas, transport, tpl, lk, post_date):
    V = []
    def v(check, a=None, b=None, c=None, status="OK"): V.append([bda, check, a, b, c, status])
    inv, pack = d["inv"], d["pack"]
    if not pack: v("No packing list found (Mainland PACKING LIST .XLS or packing page of the invoice PDF)", status="MISMATCH"); return None, V
    if not inv:
        inv = {"no": bda, "lines": [], "factory_inv": None, "date": None, "sail": None, "method": None}
        v("No Mainland commercial invoice found: prices cannot be cross-checked, ship date unknown", status="REVIEW")
    fty = inv.get("factory_inv")
    lines = pack["lines"]
    def po_qty(ls):
        d2 = defaultdict(float)
        for l in ls: d2[l["po"]] += l["qty"]
        return d2
    mine = po_qty(lines)
    def score(ux):
        o = po_qty(ux["lines"]); return sum(1 for k in mine if abs(o.get(k, 0) - mine[k]) < 1e-6) / max(len(mine), 1)
    u = unimas.get(fty) if fty else None
    best = max(unimas.values(), key=score) if unimas else None
    if best and score(best) >= 0.9 and (u is None or score(u) < score(best)):
        if u is not None: v(f"Mainland invoice cites factory invoice {fty} but the packing list matches Unimas {best['no']}; using {best['no']} (factory document error)", status="REVIEW")
        elif fty: v(f"Mainland invoice cites factory invoice {fty}; the supplied Unimas workbook {best['no']} matches the packing list; using it", status="REVIEW")
        u, fty = best, best["no"]
    if fty: inv = dict(inv, factory_inv=fty)
    if fty and not u: v(f"Unimas workbook {fty} not supplied; factory cross-check and customer refs skipped", status="INFO")
    sources = list(dict.fromkeys(s for s in (d["inv_src"], d["pack_src"], d["fs_src"], u["src"] if u else None) if s))
    umode = (u.get("mode") or "").upper() if u else None
    air = (inv.get("method") or "").upper() in ("AIR", "COURIER") or umode == "AIR"
    if inv.get("method") and umode and (inv["method"].upper() == "SEA") != (umode == "SEA"):
        v(f"Shipping method: Mainland invoice says {inv['method']}, Unimas packing list says {umode}; using {'AIR' if air else 'SEA'}", status="REVIEW")
    courier = (inv.get("carrier") or "").upper().startswith(("FEDEX", "UPS", "DHL"))
    if courier and not air:
        v(f"Mainland invoice says {inv.get('method')} but the carrier is a courier ({inv.get('carrier')}); treated as AIR", status="REVIEW"); air = True
    gen_ctn0 = sum(l["ctn"] for l in lines); gen_gw0 = round(sum(l["gw"] for l in lines), 2)
    # transport references: by factory invoice, verified against carton count / gross weight when the document carries them
    tr = {}
    cands = []
    for t in transport:
        for p in t.get("psa", []): cands.append(("psa", p))
        if t.get("container") or t.get("hbl"): cands.append(("doc", t))
        for p in t.get("psa", []): p.setdefault("src", t.get("src"))
    def fits(c):
        n, gw = c.get("cartons"), c.get("gw")
        return (n is None or n == gen_ctn0) and (gw is None or abs(gw - gen_gw0) < 0.5)
    by_inv = [c for k, c in cands if fty and c.get("factory_inv") == fty]
    chosen = [c for c in by_inv if fits(c)]
    if by_inv and not chosen:
        alt = [c for k, c in cands if fits(c) and c.get("cartons") is not None]
        if alt:
            chosen = alt; v(f"Transport document for {fty} does not match this packing list ({gen_ctn0} ctn / {gen_gw0} kg); using the one that does: {alt[0].get('hbl') or alt[0].get('container')}", status="REVIEW")
        else: v(f"Transport document for {fty} carries different cartons/weight than this packing list; references not applied", status="REVIEW")
    for c in chosen:
        tr.update({k: c[k] for k in ("container", "seal", "hbl", "mbl", "mawb", "on_board", "flight", "flight_date", "vessel", "size") if c.get(k)})
        if c.get("cartons") is not None: tr["psa_ctn"], tr["psa_gw"] = c.get("cartons"), c.get("gw")
        if "DRAFT" in str(c.get("src", "")).upper(): tr["draft"] = c["src"]
    if tr.get("vessel"): tr["vessel"] = re.sub(r"\s+V-\w+$", "", tr["vessel"]).strip()   # SAP U_VesselName carries no voyage number
    if tr.get("mawb"): tr["mawb"] = tr["mawb"].lstrip("0")
    if tr.get("draft"): v(f"Transport references taken from a DRAFT ({tr['draft']}): confirm flight/MAWB/on-board date on the final document", status="REVIEW")
    if tr.get("size"):
        sz = tr["size"].upper(); tr["size_label"] = "40' HQ" if sz.startswith("40") else "20'" if sz.startswith("20") else sz
    if courier: tr["carrier"] = None
    elif air and tr.get("flight"): tr["carrier"] = AIRLINES.get(tr["flight"][:2])
    elif not air and (tr.get("mbl") or "").startswith("ONEY"): tr["carrier"] = "OCEAN NETWORK EXPRESS (NORTH AMERICA) INC"
    # ship date
    ship = tr.get("on_board") or tr.get("flight_date") or inv.get("sail") or (u["date"] if u else None) or post_date
    if tr.get("on_board") or tr.get("flight_date"): v("Ship date from transport document (on-board / flight date)", tr.get("on_board") or tr.get("flight_date"), inv.get("sail"), ship, "OK")
    elif inv.get("sail"): v("Ship date = Mainland 'Sailing on or about'; no transport document to confirm (SAP history: 0-2 days later for sea, 1-2 days for air)", inv.get("sail"), None, ship, "REVIEW")
    else: v("Ship date unknown (no sailing date on documents); set to posting date", None, None, ship, "REVIEW")
    shipper = inv.get("shipper") or "UNIMAS SPORTSWEAR LTD."
    vendor = dict(code=f"LOOKUP:CardCode[PO vendor; shipper {shipper}]", name=f"LOOKUP:CardName[{shipper}]", address=NULL)
    coo = {"BANGLADESH": "BD", "CHINA": "CN", "VIETNAM": "VN", "THAILAND": "TH", "INDIA": "IN"}.get((inv.get("coo") or "BANGLADESH").upper(), "BD")
    # recover PO# garbled by PDF text wrap from the invoice line with the same PI#
    for l in lines:
        if l["po"] is None and l["pi"]:
            cands = {il["po"]: il for il in inv.get("lines", []) if il["pi"] == l["pi"] and il["po"]}
            if len(cands) == 1:
                il = next(iter(cands.values())); l["po"], l["prefix"] = il["po"], il.get("prefix")
                v(f"PO# recovered from invoice by PI# {l['pi']}: PO {l['po']} (packing cell read as '{l['po_raw']}')", status="REVIEW")
    for l in lines:
        if l["po"] is None: v(f"PO# does not parse: '{l['po_raw']}' (PI {l['pi']}, qty {l['qty']}); row dropped", status="MISMATCH")
    lines = [l for l in lines if l["po"] is not None]
    inv_po, fs_po = defaultdict(list), defaultdict(list)
    for il in inv.get("lines", []): inv_po[il["po"]].append(il)
    for fl in (d["fs"] or {}).get("lines", []): fs_po[fl["po"]].append(fl)
    groups = group_lines(lines)
    for g in groups:
        for m in g:
            cands = inv_po.get(m["po"], [])
            il = next((x for x in cands if abs((x["qty"] or 0) - m["qty"]) < 1e-6), None) or (cands[0] if len(cands) == 1 else None)
            m["inv_price"] = il["price"] if il else None
            fc = fs_po.get(m["po"], [])
            fl = next((x for x in fc if abs((x["qty"] or 0) - m["qty"]) < 1e-6), None) or (fc[0] if len(fc) == 1 else None)
            m["fs_price"] = fl["price"] if fl else None
            if not cands and inv.get("lines"): v(f"PO {m['po']} on packing list but not on Mainland invoice", status="REVIEW")
    if inv.get("lines"):
        packed = {l["po"] for l in lines}
        for po in inv_po:
            if po not in packed: v(f"PO {po} on Mainland invoice but not on packing list", status="MISMATCH")
    # reconciliation
    tot = pack.get("totals") or {}
    gen_qty = sum(l["qty"] for l in lines); gen_ctn = sum(l["ctn"] for l in lines)
    gen_gw = round(sum(l["gw"] for l in lines), 2); gen_cbm = round(sum(l["cbm"] for l in lines), 2)
    def chk(name, a, b, c, tol, hard):
        ok = all(abs(x - c) <= tol for x in (a, b) if x is not None)
        v(name, a, b, c, "OK" if ok else ("MISMATCH" if hard else "REVIEW"))
    chk("Pieces (invoice | packing totals | lines)", inv.get("tot_qty"), tot.get("qty"), gen_qty, 0, True)
    chk("Cartons (PSA/Unimas | packing totals | lines)", tr.get("psa_ctn") or (u or {}).get("cartons"), tot.get("ctn"), gen_ctn, 0, True)
    chk("Gross weight kg", tr.get("psa_gw") or (u or {}).get("inv_gw"), tot.get("gw"), gen_gw, 0.05, False)
    chk("CBM", None, tot.get("cbm"), gen_cbm, 0.05, False)
    if u:
        uq = sum(l["qty"] for l in u["lines"]); uc = sum(l["ctn"] for l in u["lines"])
        if uq != gen_qty or uc != gen_ctn: v(f"Unimas {fty} totals differ from Mainland packing list", f"{uq} pcs / {uc} ctn", f"{gen_qty} pcs / {gen_ctn} ctn", None, "MISMATCH")
        upo, mpo = defaultdict(float), defaultdict(float)
        for l in u["lines"]: upo[l["po"]] += l["qty"]
        for l in lines: mpo[l["po"]] += l["qty"]
        for po in sorted(set(upo) | set(mpo), key=str):
            if abs(upo.get(po, 0) - mpo.get(po, 0)) > 1e-6: v(f"PO {po}: Unimas qty {upo.get(po, 0):g} vs Mainland packing qty {mpo.get(po, 0):g}", status="MISMATCH")
        ures = {l["po"]: l["custref"] for l in u["lines"] if l["custref"]}
        for g in groups:
            for m in g:
                if not m["custref"] and ures.get(m["po"]): m["custref"] = ures[m["po"]]
    for l in lines:
        if l["ctn_e"] - l["ctn_s"] + 1 != l["ctn"]: v(f"Carton range {l['ctn_s']}-{l['ctn_e']} != CTN {l['ctn']} ({l['po_raw']} {l['item']})", status="REVIEW")
        if l["qty_ctn"] * l["ctn"] != l["qty"]: v(f"QTY/CTN x CTN != pcs ({l['po_raw']} {l['item']} {l['color']})", None, l["qty"], l["qty_ctn"] * l["ctn"], "REVIEW")
    spans = sorted((l["ctn_s"], l["ctn_e"]) for l in lines); gaps = [(e1, s2) for (s1, e1), (s2, e2) in zip(spans, spans[1:]) if s2 != e1 + 1]
    if gaps: v(f"Carton numbering not contiguous ({len(gaps)} gap(s)/restart(s), e.g. {gaps[0][0]} -> {gaps[0][1]}); factory numbering kept as printed", status="INFO")
    if air and not courier and not tr.get("hbl"): v("Air (forwarder) shipment: HAWB number not found in the supplied documents (DML-xxxxx draft)", status="REVIEW")
    if air and courier: v("Courier shipment: tracking number (U_AWB / U_ContREfNo) is on the shipping-label scan, not in these documents", status="REVIEW")
    if not air and not tr.get("container"): v("Sea shipment: container / seal / HBL not found (supply the DML-xxxxx HBL draft or the PSA shipment advice)", status="REVIEW")
    if not air: v("U_GrossWeight / U_DimWeight for sea: SAP history holds one representative per-carton G.W / N.W; file carries the carton-weighted average kg", round(gen_gw / gen_ctn, 2) if gen_ctn else None, None, None, "REVIEW")
    if d["fs"]:
        ratios = {round(m["fs_price"] / m["inv_price"], 2) for g in groups for m in g if m.get("fs_price") and m.get("inv_price")}
        if ratios and max(ratios) < 0.82: v(f"First Sales invoice {d['fs_src']} prices are {sorted(ratios)} of the Mainland price; SAP history holds the 84% revision - confirm which is final", status="REVIEW")
    elif not air or True:
        v("No First Sales (TH-) invoice supplied; U_FirstSalePrice / U_FirstSaleTotal left 0", status="INFO")
    # ---- rows
    ctx = dict(inv=inv, air=air, courier=courier, transport=tr, vendor=vendor, post_date=post_date, ship_date=ship, coo=coo, sources=sources)
    hdr_cols, hdr_ex = tpl["OPDN_Header"]; line_cols, line_ex = tpl["PDN1_Line"]
    H, Lr, K = [], [], []
    for docentry, g in enumerate(groups, 1):
        hrow = header_row(ctx, g, docentry, hdr_cols, hdr_ex)
        cardcodes, doc_total, fs_total, lrows = set(), 0.0, 0.0, []
        drawn = defaultdict(lambda: [0, None, []])
        i = 0
        while i < len(g):
            m = g[i]; lrow = line_row(ctx, m, docentry, i, line_cols, line_ex)
            if lk and m["mixed"]:
                r0, st0, _ = resolve(m, lk)
                over = r0 is not None and (num(r0.get("OpenQty")) or 0) < m["qty"] - 1e-6
                parts, used = [], set()
                for x in m["rows"]:
                    rx, sx, _ = resolve(dict(x, mixed=False, packing=""), lk, exclude=used)
                    if rx is None or sx != "OK" or (num(rx.get("OpenQty")) or 0) < x["qty"] - 1e-6: parts = None; break
                    used.add((int(num(rx["BaseEntry"])), int(num(rx["BaseLine"])))); parts.append(x)
                if (r0 is None or over) and parts:
                    v(f"PO {m['po']} {m['item']}: packing rows share PI/SEQ but the PO has one line per row; received on separate lines", status="REVIEW")
                    g[i:i + 1] = [dict(x, rows=[x], mixed=False, packing=f"{x['ctn']}-{x['qty_ctn']}", inv_price=m.get("inv_price"), fs_price=m.get("fs_price")) for x in m["rows"]]
                    m = g[i]; lrow = line_row(ctx, m, docentry, i, line_cols, line_ex)
            if lk:
                r, status, note = resolve(m, lk)
                if r:
                    apply_lookup(lrow, r); cardcodes.add(r["CardCode"]); doc_total += lrow["LineTotal"] or 0
                    dd = drawn[(lrow["BaseEntry"], lrow["BaseLine"])]; dd[0] += m["qty"]; dd[1] = num(r.get("OpenQty")); dd[2].append(f"{m['item']} {m['color']}")
                    if m.get("inv_price") is not None and abs(m["inv_price"] - (lrow["Price"] or 0)) > 0.0051:
                        v(f"PO {m['po']} {lrow['ItemCode']}: SAP PO price {lrow['Price']} vs Mainland invoice price {m['inv_price']}", lrow["Price"], m["inv_price"], None, "REVIEW")
                    if r.get("U_POPrefix") and m["prefix"] and str(r["U_POPrefix"]) != m["prefix"]: v(f"PO {m['po']} prefix: packing {m['prefix']} vs SAP {r['U_POPrefix']}", status="REVIEW")
                    if m["prefix"] in STOCK_PREFIXES and m.get("paren") and r.get("U_MxPrStyl") not in (None, "", NULL):
                        mx, px = str(r["U_MxPrStyl"]).upper(), m["paren"].upper()
                        if not (mx == px or mx.endswith(px) or px.endswith(mx)): v(f"PO {m['po']} {m['item']}: packing style {m['paren']} vs OITM.U_MxPrStyl {r['U_MxPrStyl']}", status="REVIEW")
                if status != "OK": v(f"Lookup PO {m['po']} {m['item']} {m['color']}: {note}", None, m["qty"], None, status)
                if not r: K.append([docentry, m["po"], m["item"], m["color"], m["qty"], f"UNRESOLVED - {note}"])
            else:
                K.append([docentry, m["po"], m["item"], m["color"], m["qty"], "BaseEntry, BaseLine, Price, U_FOBPrice (ItemCode is the SAP SKU for stock lines)"])
            if m.get("fs_price"): fs_total += m["fs_price"] * m["qty"]
            lrows.append(lrow); i += 1
        for (be, bl), (q, oq, rows_) in drawn.items():
            if oq is not None and q > oq + 1e-6: v(f"over-receipt on PO line (BaseEntry {be}, line {bl}): packing {q:g} vs open {oq:g} ({'; '.join(rows_)})", None, q, oq, "MISMATCH")
        if lk and cardcodes:
            if len(cardcodes) > 1: v(f"POs on this GRPO belong to different vendors: {sorted(cardcodes)}", status="MISMATCH")
            cc = sorted(cardcodes)[0]
            r0 = next((rr for m in g for rr in [resolve(m, lk)[0]] if rr and rr["CardCode"] == cc), None)
            hrow.update({"CardCode": cc, "JrnlMemo": f"Goods Receipt PO - {cc}", "DocTotal": round(doc_total, 4), "DocTotalSy": round(doc_total, 4)})
            if r0 and r0.get("CardName"): hrow["CardName"] = r0["CardName"]
            if len({m["po"] for m in g}) == 1 and r0:
                for k in ("U_SONo", "U_CustRefNo"):
                    if r0.get(k) not in (None, "", NULL): hrow[k] = r0[k]
            for lrow in lrows: lrow["BaseCard"] = cc
        elif not lk: K.append([docentry, None, None, None, None, f"CardCode / CardName / Address of the PO vendor (shipper {shipper}; example data: Mainland Sewing V00313)"])
        hrow["U_FirstSaleTotal"] = round(fs_total, 4) if fs_total else 0
        H.append(hrow); Lr += lrows
    if lk: v(f"PO lookup table ExportedAt {lk['exported']}", status="OK")
    v(f"GRPOs generated: {len(groups)} ({'SPO/VAC and other POs posted separately' if len(groups) == 2 else 'single group'})", None, None, len(groups), "OK")
    return dict(H=H, L=Lr, K=K, hdr_cols=hdr_cols, line_cols=line_cols), V

def write_workbook(res, V, out_path, emit_csv):
    wb = openpyxl.Workbook()
    ws_h = wb.active; ws_h.title = "OPDN_Header"; ws_h.append(res["hdr_cols"])
    ws_l = wb.create_sheet("PDN1_Line"); ws_l.append(res["line_cols"])
    ws_gh = wb.create_sheet("GRPO_Header"); ws_gh.append(LEAN_HDR)
    ws_gl = wb.create_sheet("GRPO_Lines"); ws_gl.append(LEAN_LINE)
    ws_v = wb.create_sheet("Validation"); ws_v.append(["File", "Check", "Invoice", "Packing", "Generated", "Status"])
    ws_k = wb.create_sheet("Lookups_Needed"); ws_k.append(["DocEntry", "PO", "ItemCode", "Color", "Qty", "Needs"])
    for h in res["H"]: ws_h.append([h[c] for c in res["hdr_cols"]]); ws_gh.append([h.get(c, NULL) for c in LEAN_HDR])
    for l in res["L"]: ws_l.append([l[c] for c in res["line_cols"]]); ws_gl.append([l.get(c, NULL) for c in LEAN_LINE])
    for r in V: ws_v.append(r)
    for r in res["K"]: ws_k.append(r)
    for ws in (ws_h, ws_l, ws_gh, ws_gl):
        hdr = [c.value for c in ws[1]]
        for row in ws.iter_rows(min_row=2):
            for c in row:
                if isinstance(c.value, (dt.date, dt.datetime)): c.number_format = "yyyy-mm-dd"
                if hdr[c.column - 1] in ("U_CartonNo", "U_Packing") and c.value not in (None, NULL): c.number_format = "@"; c.value = str(c.value)
    wb.save(out_path)
    print_summary(out_path, res, V, emit_csv)

def print_summary(out_path, res, V, emit_csv):
    review = [r for r in V if r[5] == "REVIEW"]; mism = [r for r in V if r[5] == "MISMATCH"]; info = [r for r in V if r[5] == "INFO"]
    unresolved = len(res["K"]); H, Lr = res["H"], res["L"]
    exported = next((r[1].split("ExportedAt ", 1)[1] for r in V if "ExportedAt" in str(r[1])), "none")
    h0 = H[0]; sea = h0["TrnspCode"] == 1
    print("=== GRPO SUMMARY ===")
    print(f"File: {os.path.basename(out_path)}")
    print(f"Invoice: {h0['NumAtCard']}  Factory invoice: {h0['_FactoryInv']}  Posting date: {h0['DocDate']}  Ship date: {h0['DocDueDate']}  Mode: {'SEA' if sea else 'AIR'} {h0['U_MOT']}")
    print(f"Vendor: {h0['CardCode']} {h0['CardName']}  Ship-to: {h0['_ShipTo']}")
    for h in H:
        ls = [l for l in Lr if l["DocEntry"] == h["DocEntry"]]
        print(f"GRPO {h['DocEntry']}: {len(ls)} lines, {sum(l['Quantity'] for l in ls):,} pcs, {h['U_NumCartons']} ctn, CBM {h['U_CubeMeters']}, {h['Comments'][:100]}")
    print(f"Transport: container {h0['U_ContREfNo']}  seal {h0['U_SealRefNo']}  HBL/AWB {h0['U_BOLNo'] if sea else h0['U_AWB']}  MBL/MAWB {h0['U_MasterBLNo'] if sea else h0['U_MAWBNo']}  vessel {h0['U_VesselName']}")
    print(f"Sources: {h0['_Sources']}")
    print(f"Lookup snapshot ExportedAt: {exported}")
    print(f"REVIEW: {len(review)}  MISMATCH: {len(mism)}  INFO: {len(info)}  Unresolved lookups: {unresolved}")
    print("Ready to post: " + ("NO" if mism or unresolved else "YES"))
    fmt = lambda r: f" [{r[2]} | {r[3]} | {r[4]}]" if any(x is not None for x in r[2:5]) else ""
    for r in mism: print(f"  MISMATCH - {r[1]}{fmt(r)}")
    for r in review: print(f"  REVIEW   - {r[1]}{fmt(r)}")
    for r in info: print(f"  INFO     - {r[1]}")
    if emit_csv:
        for name, cols, rows in (("GRPO_Header", LEAN_HDR, H), ("GRPO_Lines", LEAN_LINE, Lr)):
            buf = io.StringIO(); w = csv.writer(buf); w.writerow(cols)
            for r in rows: w.writerow(["" if r.get(c) is None else r.get(c, NULL) for c in cols])
            print(f"=== CSV {name} ===\n{buf.getvalue().rstrip()}")

def main(argv):
    args = list(argv)
    def opt(name, default):
        if name in args:
            i = args.index(name); val = args[i + 1]; del args[i:i + 2]; return val
        return default
    lookup = opt("--lookup", None); post = opt("--post-date", None); out_dir = opt("--out", os.path.join(os.getcwd(), "out"))
    template = opt("--template", os.path.join(HERE, "..", "examples", "OPDN_Excel_template.xlsx")); only = opt("--invoice", None)
    emit_csv = "--emit-csv" in args; args = [a for a in args if a != "--emit-csv"]
    if not args: sys.exit(__doc__)
    post_date = to_date(post) if post else dt.date.today()
    os.makedirs(out_dir, exist_ok=True)
    tpl = load_template(template); lk = load_lookup(lookup) if lookup else None
    B, unimas, transport = discover(args)
    for t in transport:
        if t.get("error"): print(f"WARNING: could not read {t['src']}: {t['error']}")
    if not B:
        if unimas: print("MISMATCH: only Unimas EX/UNI workbook(s) supplied; the GRPO is keyed by the Mainland BDA invoice (NumAtCard). Supply the Mainland invoice/packing list for: " + ", ".join(unimas))
        sys.exit("No Mainland (BDA) invoice found in the inputs.")
    outs = []
    for bda in sorted(B):
        if only and bda != only: continue
        res, V = build_invoice(bda, B[bda], unimas, transport, tpl, lk, post_date)
        if res is None:
            print(f"=== GRPO SUMMARY ===\nFile: (none)\nInvoice: {bda}\nReady to post: NO")
            for r in V: print(f"  {r[5]} - {r[1]}")
            continue
        p = os.path.join(out_dir, f"OPDN_upload_{bda}.xlsx"); write_workbook(res, V, p, emit_csv); outs.append(p)
    return outs

if __name__ == "__main__":
    main(sys.argv[1:])
