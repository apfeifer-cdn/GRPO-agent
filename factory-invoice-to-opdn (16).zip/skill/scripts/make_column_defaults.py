"""Emit references/opdn-column-defaults.csv: every template column with its class and value rule.
Usage: python make_column_defaults.py ../examples/OPDN_Excel_template.xlsx ../references/opdn-column-defaults.csv"""
import csv, sys, datetime as dt
sys.path.insert(0, __file__.rsplit("/", 1)[0])
from build_opdn import load_template, SYSTEM_HDR, SYSTEM_LINE, OPEN_STATUS

SOURCE_HDR = {
    "DocEntry": "1 (and 2 when SPO/VAC and other prefixes are both present)",
    "DocDate": "posting date (--post-date)", "TaxDate": "= DocDate",
    "DocDueDate": "ship date: HBL on-board / flight date, else Mainland 'Sailing on or about'",
    "CardCode": "LOOKUP PO vendor CardCode", "CardName": "LOOKUP PO vendor CardName (Mainland Sewing in examples)",
    "Address": "NULL (vendor master)", "Address2": "'KS USA'",
    "NumAtCard": "Mainland invoice no. BDAnnnnnnnn", "U_FactoryInv": "= NumAtCard",
    "Comments": "'Based On Purchase Orders <po>. <po>.' ascending",
    "JrnlMemo": "'Goods Receipt PO - <CardCode>'",
    "U_OrderNo": "PO number when a single PO, else NULL", "U_POPrefix": "prefix of the lowest PO number",
    "U_CustRefNo": "LOOKUP PO U_CustRefNo when a single PO", "U_SONo": "LOOKUP PO U_SONo when a single PO",
    "TrnspCode": "1 sea / 37 air", "U_MOT": "container size from HBL/PSA ('40' HQ', '20'') or 'Air - Collect'",
    "U_FOB": "'Chittagong, Bangladesh' sea / 'Dhaka, Bangladesh' air", "U_FCAAirport": "'Dhaka, Bangladesh' air only",
    "U_OceanDest": "'Kansas City, KS' sea only", "U_ShipVia": "'Demotrans' sea / 'AIR' air",
    "U_Notify": "'Bestway International' sea / 'Bestway' air / 'FedEx Courier' courier",
    "U_Carrier": "MBL prefix ONEY -> 'OCEAN NETWORK EXPRESS (NORTH AMERICA) INC'; airline from flight prefix",
    "U_BLConsig": "'Design Resources, Inc.'", "U_GenConsig": "'Design Resources, Inc.'",
    "U_COO": "country of origin on the invoice ('BD')", "U_TermSale": "'FOB'", "U_MakerTerms": "'CDN'",
    "U_HandoverDate": "NULL", "U_NumCartons": "sum CTN of this GRPO's lines", "U_CubeMeters": "sum CBM of this GRPO's lines (2 dp)",
    "U_GrossWeight": "air: total gross kg; sea: representative per-carton G.W kg (REVIEW)",
    "U_DimWeight": "air: total net kg; sea: representative per-carton N.W kg (REVIEW)",
    "U_ContREfNo": "container (sea) / HAWB or tracking (air)", "U_SealRefNo": "seal (sea)", "U_BOLNo": "HBL DMLnnnnn (sea)",
    "U_MasterBLNo": "MBL (sea)", "U_AWB": "HAWB / tracking (air)", "U_MAWBNo": "MAWB digits (air)",
    "U_VesselName": "vessel without voyage (sea) / flight (air)", "U_FirstSaleTotal": "sum First Sales price x qty (0 if none)",
    "Weight": "NULL (SAP computes)", "Volume": "NULL (SAP computes)", "WeightUnit": "3", "VolUnit": "4",
}
SOURCE_LINE = {
    "DocEntry": "parent OPDN_Header.DocEntry", "LineNum": "0..n within GRPO, ordered by PO then SEQ PI#", "VisOrder": "= LineNum",
    "BaseType": "22 (Purchase Order)", "U_BaseType": "22", "BaseRef": "PO number", "BaseDocNum": "PO number",
    "BaseEntry": "LOOKUP PO DocEntry", "BaseLine": "LOOKUP PO line (U_Proto/ItemCode/C-number/style + colour; ties by open qty then SEQ PI#)",
    "U_BaseEntry": "= BaseEntry", "U_BaseLine": "= BaseLine", "BaseCard": "= header CardCode",
    "ItemCode": "LOOKUP SAP SKU (packing style before '(' / before '-colour' as the key)", "Dscription": "LOOKUP PO line description (packing DESCRIPTION fallback)",
    "Quantity": "sum pcs of the PO line's packing rows", "InvQty": "= Quantity", "PackQty": "= Quantity", "BaseQty": "= Quantity",
    "ShipDate": "= header DocDueDate", "ActDelDate": "= header DocDate",
    "Price": "LOOKUP PO line Price (cross-checked against the Mainland invoice)", "U_FOBPrice": "LOOKUP PO line U_FOBPrice",
    "U_FirstSalePrice": "First Sales invoice unit price (0 if none)", "LineTotal": "Quantity x Price",
    "Currency": "'$'", "WhsCode": "'2'", "CountryOrg": "= header U_COO", "TrnsCode": "= header TrnspCode",
    "U_Color": "LOOKUP PO line U_Color (NULL when the PO line has none); packing colour for SPO/VAC without lookup",
    "U_LinePOPrefix": "PO# prefix", "U_CustPO": "customer ref (Unimas PO# token or LOOKUP U_CustRefNo)",
    "U_CartonNo": "'<min CTN.(S)>-<max CTN.(E)>' as text", "U_PcsPerCarton": "full-carton QTY/CTN", "U_NumfCart": "sum CTN",
    "U_Packing": "'<ctn>-<pcs>, ...' as text, mixed packing only",
    "U_CartonWeight": "G.W/CTN kg x 2.20462 (lb)", "U_CartonLength": "LENGTH cm / 2.54", "U_CartonWidth": "WIDTH cm / 2.54", "U_CartonHeight": "HEIGHT cm / 2.54",
    "FreeTxt": "PI <PI#> seq <SEQ>; packing style <STYLE#>; color <COLOUR>; cust ref <ref>; mixed packing <U_Packing>",
}

def classify(sheet, col, ex):
    src = (SOURCE_HDR if sheet == "OPDN_Header" else SOURCE_LINE)
    sysset = SYSTEM_HDR if sheet == "OPDN_Header" else SYSTEM_LINE
    if col in src:
        rule = src[col]
        return ("LOOKUP" if "LOOKUP" in rule else "SOURCE"), rule
    if sheet == "OPDN_Header" and col in OPEN_STATUS:
        return "CONST", OPEN_STATUS[col]
    if sheet == "PDN1_Line" and col in ("LineStatus", "InvntSttus"):
        return "CONST", "O"
    if col in sysset:
        return "SYSTEM", "leave NULL - SAP assigns or derives from the PO"
    if ex is None or ex == "NULL":
        return "NULL", "NULL"
    if isinstance(ex, dt.datetime):
        return "SYSTEM", "leave NULL"
    return "CONST", ex

if __name__ == "__main__":
    tpl = load_template(sys.argv[1])
    with open(sys.argv[2], "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Sheet", "Column", "Class", "Value or source rule", "Template example"])
        for sheet, (hdr, ex) in tpl.items():
            for col in hdr:
                cls, rule = classify(sheet, col, ex.get(col))
                w.writerow([sheet, col, cls, rule, ex.get(col)])
    print("ok")
