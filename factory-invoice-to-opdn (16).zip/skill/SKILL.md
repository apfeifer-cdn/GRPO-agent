---
name: factory-invoice-to-opdn
description: Turn a factory shipment's documents (Mainland BDA invoice + packing list, Unimas EX/UNI workbook, First Sales invoice, HBL/HAWB/PSA) into an SAP B1 GRPO upload file (OPDN_Header / PDN1_Line) for DRI - keyed by the Mainland BDA invoice, one GRPO line per PO line, SPO/VAC posted separately, with reconciliation and a lookup list.
---

# Factory shipment documents → OPDN (GRPO) upload

## Purpose
Produce an Excel workbook shaped exactly like `examples/OPDN_Excel_template.xlsx` so a Goods
Receipt PO can be posted in SAP Business One. Rules below were derived from 72 posted GRPOs
(494 lines, 63 invoices) compared with their source documents; where SAP practice is
inconsistent the file carries the majority convention and the Validation sheet says so.

## Inputs (any mix, grouped automatically by the Mainland invoice number `BDAnnnnnnnn`)
| Document | Typical file | Gives |
|---|---|---|
| Mainland commercial invoice | `<BDA> INVOICE <seq>.xlsx` or `<BDA> -<seq>.pdf` | NumAtCard, shipper, ship-to, **unit prices**, sailing date, method, carrier, factory invoice no. |
| Mainland packing list | `<BDA> PACKING LIST <seq>.XLS` or packing pages of the PDF | **the lines** (PI#, SEQ PI#, PO#, style, colour, cartons, weights, CBM) |
| Unimas factory workbook | `Invoice & Packing List - <seq> (...).xls` (`EX/UNI/<seq>/<yyyy>`) | cross-check, customer ref on PO#, ship mode |
| First Sales invoice | `First Sales <BDA>.xls` / `<BDA> -1st Sales.pdf` (`TH-<BDA>`) | `U_FirstSalePrice`, `U_FirstSaleTotal` |
| HBL/HAWB draft, PSA, shipment advice | `DML-nnnnnDRAFT.pdf`, `PSA_DML-….pdf`, `SA DRI Caps ….xlsx` | container, seal, HBL/MBL, vessel, on-board date |
| PO lookup table | `po_lookup.xlsx/csv` (`references/po-lookup-table.md`) | BaseEntry/BaseLine, Price, CardCode, SAP ItemCode, PO colour |

The GRPO is **keyed by the Mainland BDA invoice** (`NumAtCard` = `U_FactoryInv` = `BDA…`),
never by `EX/UNI/…` (one EX/UNI covers up to eight BDA invoices). A Unimas workbook alone is
not enough; say so and ask for the Mainland invoice + packing list. Anatomy of every document:
`references/source-document-anatomy.md`.

## Procedure
1. Run `python scripts/build_opdn.py <folder-or-files> [--lookup po_lookup.xlsx] [--post-date YYYY-MM-DD]
   [--out out_dir] [--invoice BDA…] [--emit-csv]`. It discovers the documents, builds one
   workbook per BDA invoice (`OPDN_upload_<BDA>.xlsx`) and prints a `=== GRPO SUMMARY ===`
   block per invoice. Relay that block verbatim, then the workbook.
2. If there is no lookup table, the file carries `LOOKUP:` placeholders and a `Lookups_Needed`
   sheet. Offer the SQL in `references/po-lookup-table.md` (or the Service Layer recipe in
   `references/service-layer-po-lookup.md`) to export the open PO lines, then re-run with `--lookup`.
3. Read the Validation sheet: MISMATCH blocks posting; REVIEW needs a human decision; INFO is
   context. Meanings: `references/validation-rules.md`.

## Rules the script encodes (do not override by hand)
- **Grouping.** Lines whose PO prefix is `SPO` or `VAC` (stock/matrix programs) are posted on
  their own GRPO; all other prefixes on another. Header cartons/CBM are subtotals per GRPO
  (9 of 9 mixed invoices in the examples).
- **Merging.** One GRPO line per PO line: packing rows with the same PO + PI# + SEQ PI# + colour
  are summed (`Quantity`, `U_NumfCart`); `U_PcsPerCarton` = the full-carton count;
  `U_CartonNo` = min–max range; `U_Packing` = `"3-144, 1-72"` (text). With a lookup, rows that
  share a SEQ but match separate PO lines are kept separate (REVIEW).
- **Dates.** `DocDate` = `TaxDate` = `ActDelDate` = posting date (`--post-date`, default today).
  `DocDueDate` = line `ShipDate` = ship date: HBL on-board / flight date if supplied, else the
  Mainland "Sailing on or about" (REVIEW: SAP history is 0–2 days later). `U_HandoverDate` stays
  NULL (the Unimas ICD date never matched it).
- **Header.** `TrnspCode` 1 sea / 37 air (also line `TrnsCode`); `U_MOT` = container size
  (`40' HQ`, `20'`) or `Air - Collect`; `U_FOB` Chittagong (sea) / Dhaka (air); `U_FCAAirport`
  Dhaka for air; `U_OceanDest` Kansas City, KS for sea; `U_ShipVia` Demotrans / AIR;
  `U_Notify` Bestway International / Bestway / FedEx Courier; `U_Carrier` from MBL (ONE) or
  flight prefix; `U_POPrefix` = prefix of the lowest PO number; `Comments` =
  `Based On Purchase Orders 120601. 120603.`; `U_GrossWeight`/`U_DimWeight` = total gross/net kg
  for air, representative per-carton kg for sea (REVIEW); `Weight`/`Volume` left to SAP.
- **Lines.** `WhsCode` 2; `Dscription` and `Price` from the PO; `U_Color` only when the PO line
  carries a colour (always SPO/VAC; never pure custom lines); `U_CustPO` = customer ref (Unimas
  PO# token or PO export); carton weight in lb and dimensions in inches (SAP history is mostly
  0 or a default carton, so these are informational); `FreeTxt` keeps PI#, SEQ, packing style,
  colour, mixed packing.
- **Lookup matching.** PO + SAP `U_Proto` = packing C-number → PO + ItemCode → C-number with
  colour/size suffix (revision letters `C24-10449A` tolerated) → customer style id / paren text
  (`VC6440` for `(6440)`, `AH30A` for `(AH30)`, `DON-1500CT-…` for `1500CT`) → SAP SKU that
  starts with / contains the packing item. Ties: exact open quantity, then SEQ PI# = PO line + 1,
  then ordered quantity, then lowest line that covers. 493 of 494 example lines resolve to the
  posted PO line; the remaining one is a REVIEW (two identical open lines).
- **Price check.** Mainland unit price vs SAP PO price: REVIEW when they differ by more than
  0.005 (2 of 492 examples).
- **First sales.** Two revisions circulate (79 % and 84 % of the Mainland price); SAP holds the
  84 % one. A 79 % file is flagged REVIEW.
- **Known factory-document errors handled.** Wrong `Factory INVOICE:` on the Mainland invoice
  (resolved by PO/qty match against the supplied Unimas workbooks), `SEA` printed on a courier
  invoice (carrier wins), PDF text wrap garbling PO#/style cells (PO recovered by PI# from the
  invoice; style re-joined).

## Output
Sheets `OPDN_Header`, `PDN1_Line` (full template column sets, `NULL` where SAP assigns),
`GRPO_Header`, `GRPO_Lines` (lean review views with `_`-prefixed helper columns),
`Validation`, `Lookups_Needed`. `U_CartonNo` / `U_Packing` are written as text so Excel does
not turn `1-2` into a date. Field-by-field rules: `references/opdn-field-mapping.md` and
`references/opdn-column-defaults.csv`.

## When to stop and ask
No Mainland packing list; PO# that does not parse and cannot be recovered; pieces or cartons
that do not reconcile between invoice, packing totals and lines; over-receipt against open PO
quantity; POs from different vendors on one GRPO. Never invent prices, PO keys or vendor codes.
