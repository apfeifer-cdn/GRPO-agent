# Validation rules

Sheet `Validation`: `File | Check | Invoice | Packing | Generated | Status`. Statuses:
**MISMATCH** blocks posting; **REVIEW** needs a human decision but the file is usable;
**INFO** is context. The stdout summary lists them in that order with `Ready to post: YES/NO`
(NO when any MISMATCH or unresolved lookup remains).

## MISMATCH
| Check | Meaning |
|---|---|
| No packing list found | Need the Mainland `PACKING LIST .XLS` or the packing pages of the PDF |
| Pieces / Cartons | Invoice grand total, packing totals row and summed lines disagree |
| PO on Mainland invoice but not on packing list | Invoice/packing list from different shipments or a missing page |
| Unimas totals / PO qty differ from Mainland packing list | Factory and Mainland lists disagree; confirm which is final |
| PO# does not parse (after PI# recovery) | Row dropped; fix the source |
| over-receipt on PO line | Summed receipt > open qty on the matched PO line |
| Lookup … PO line not found / no open line in colour | No PO line for this item/colour (lookup supplied) |
| POs on this GRPO belong to different vendors | Split the posting |

## REVIEW
| Check | Meaning / what to do |
|---|---|
| Ship date = Mainland 'Sailing on or about' | No HBL/HAWB supplied; SAP history posts 0–2 days later. Confirm on the final B/L |
| U_GrossWeight / U_DimWeight for sea | SAP keeps one representative per-carton G.W/N.W; file has the weighted average |
| Sea: container / seal / HBL not found; Air: HAWB not found; Courier: tracking on label scan | Supply the transport document or type the references |
| Transport references taken from a DRAFT | Flight, MAWB and on-board date may change on the final document |
| Mainland invoice cites factory invoice X but packing list matches Unimas Y | Known factory error; Y used |
| Shipping method SEA but carrier is a courier | Treated as AIR |
| PO# recovered from invoice by PI# | PDF wrap; verify the PO |
| Gross weight kg / CBM | Totals differ by > 0.05 (rounding on the factory sheet is usual) |
| Carton range != CTN; QTY/CTN × CTN != pcs | Factory arithmetic; usually a mixed carton |
| SAP PO price vs Mainland invoice price | Differ by > 0.005; price-update or invoice error (2 of 492 examples) |
| First Sales prices are 0.79 of the Mainland price | The 79 % revision; SAP holds the 84 % one |
| packing rows share PI/SEQ but the PO has one line per row | Un-merged into separate GRPO lines |
| Lookup … took the only open line / N open lines …; took line … | Match made by fallback or tie-break; confirm |
| PO prefix: packing vs SAP | Prefix typo on one side |
| packing style vs OITM.U_MxPrStyl | Matrix parent style disagrees |

## INFO
Unimas workbook not supplied; First Sales invoice not supplied; carton numbering not
contiguous (air lists restart per PO, sea lists have gaps — numbering kept as printed).

## Deliberately not flagged
- A PO appearing on several invoices (20 of 344 example POs ship in parts; no PO line was ever
  received twice).
- Many POs on one GRPO (a container consolidates 1–40 POs).
- `U_CartonNo` differing from SAP practice (SAP practice is inconsistent).
