# Source document anatomy

A shipment arrives as a bundle of files from the factory (Unimas Sportswear, Gazipur), the
Hong Kong invoicing entity (Mainland Sewing, `BDA…` invoices), the first-sale entity
(Trend Hero, `TH-BDA…`) and the forwarder (Demotrans, `DML-…`). The script identifies each by
file name and content; this page says what each contains and which values matter.

## 1. Mainland commercial invoice (`<BDA> INVOICE <seq>.xlsx`, or the first page of `<BDA> -<seq>.pdf`)
- Title `COMMERCIAL INVOICE BDAnnnnnnnn <date YYYY-MM-DD>`. `BDA` = `NumAtCard` = `U_FactoryInv`.
- `Factory INVOICE: EX/UNI/<seq>/<yyyy>` — the Unimas number. **Wrong on 2 of 63 examples**;
  the script trusts the PO/qty match against the Unimas workbooks over this field.
- `Sailing on or about: YYYY-MM-DD` — ship-date candidate. `Shipping Method: SEA|AIR|COURIER`
  (one courier invoice says SEA). `Carrier: <name>` (`FEDEX COURIER`, `ETHIOPIAN AIRLINES`,
  `OCEAN NETWORK EXPRESS …`).
- Shipper block = Mainland (CardName), Ship To block = DRI (or a drop-ship customer, e.g.
  Snowmobile Hall of Fame — informational), Country of Origin.
- Line table: `PI# | PO# | Description | HTS | Style | Qty | Unit price | Amount`; one line
  per PI (aggregates packing rows). PO# has no customer ref. `GRAND TOTAL <pcs> PCS <amount>`.
- In the PDF the same text wraps; the script uses regexes on the page text.

## 2. Mainland packing list (`<BDA> PACKING LIST <seq>.XLS`, or the packing page(s) of the PDF)
Header row starts `CTN. S)` (xls) or `CTN. (S)` (pdf). Columns, in order:
`CTN.(S) | CTN.(E) | CTN | QTY/CTN | PI# | SEQ PI# | PO# | STYLE# | COLOUR | DESCRIPTION |
QNTY PCS. | G.W | N.W | Total G.W | Total N.W | LENGTH | WIDTH | HEIGHT | CBM`
(G.W/N.W per carton, kg; dimensions cm). Totals row: `TOTAL: 405 CTN 58260 PCS G.W: … N.W: … CBM`.
- `PI#` `BA1095333` (sometimes `BA 1095333`), `SEQ PI#` = position on the PI = **PO line + 1**
  (315/317 custom lines, 145/176 stock lines).
- `PO#` `NRS121728` — prefix (3) + number (6); customer ref omitted (the Unimas list has it).
- `STYLE#`: sea lists `C17-06417(SP500)` / `C26-07527`; air/PDF lists `C26-05627-Navy`
  (colour appended, no parens); customer codes `DON-1850MB-345-OS`, `#83200TM(1850MB-997-OS)`,
  art names `UCA PURPLE BEARS SCRIPT`. Revision letters (`C24-09533C`) may differ from SAP.
- Carton numbering restarts per PO on air lists and has gaps on 8 of 30 sea lists: informational.
- Several rows per PI/SEQ mean mixed cartons (`3×144 + 1×72`); they are one PO line.
- PDF text wrap can push the style's first characters into PO# (`C2 | 3-06233-BLACK`) or make
  the PO cell unreadable; the script repairs the former and recovers the latter from the
  invoice line with the same PI#.

## 3. Unimas workbook (`Invoice & Packing List - <seq> ( Caps Direct - DD.MM.YYYY) - Sea, USA.xls` / `- AIR.xls`)
Sheets `Inv-` and `Pac-`. `Pac-` header `CTN. (S) … Total PCS. | G.W/ CTN | N.W/ CTN | Total G.W …`
(air variant has the same names with different spacing). Top block: `INVOICE NO : EX/UNI/<seq>/<yyyy>`,
`DATE : DD.MM.YYYY`, `ICD DATE`, `SHIP MODE : SEA|AIR`, `PORT OF LOADING`, `HS CODE`.
`PO#` carries the customer ref: `SPO120599  91690`. One Unimas invoice can cover several BDA
invoices (4762 ↔ BDA26091160 + BDA26091162). Used for cross-check (pcs/cartons per PO), the
customer ref, and ship mode; **not** the GRPO key, and its ICD date is not `U_HandoverDate`.

## 4. First Sales invoice (`First Sales <BDA>.xls`, `<BDA> -1st Sales.pdf`)
`COMMERCIAL INVOICE TH-BDA…`, same lines as the Mainland invoice at the first-sale price.
Two revisions exist: 79 % and 84 % of the Mainland price; SAP holds 84 %. Gives
`U_FirstSalePrice` (line) and `U_FirstSaleTotal` (header = Σ price × qty).

## 5. Transport documents
- **HBL draft** `DML-17275DRAFT.pdf` (Demotrans): `B/L NUMBER DML-17275`, `INV NO EX/UNI/…`,
  `ONEU0823350/40HC SEAL: BDA267388 405 CARTONS 6825.98 KGS 54.69 CBM`, `SHIPPED ON BOARD …
  03-OCT-2026`, vessel lines (`ONE CYGNUS V-025E`), `MBL No.`. Gives container/size/seal
  (`U_ContREfNo`, `U_MOT`, `U_SealRefNo`), `U_BOLNo`, `U_MasterBLNo`, `U_VesselName` (without
  voyage), ship date. Cartons/kg on the container line let the script verify it belongs to this
  packing list.
- **HAWB draft** `DML-15440DRAFT.pdf`: `HAWB NO. DML-15440`, flight `ET-681 11-SEP-26`, MAWB
  usually blank on the draft (SAP has the final AWB's `BA0295` / MAWB) → REVIEW "from DRAFT".
- **PSA** `PSA_DML-17273, DML-17274, DML-17275.pdf` / `SA DRI Caps -DML-17224, DML-17225.xlsx`
  (shipment advice): one block per container with size, seal, HBL, stuffing date, cartons, kg,
  CBM, factory invoice; `MBL No.`, `2nd Vessel` (mother vessel).
- **Courier labels** (`IPD 29.09.2026.pdf`, scans): FedEx tracking numbers used by SAP as
  `U_AWB` / `U_ContREfNo` / `U_MAWBNo` — not machine-readable; REVIEW asks for them.

## 6. SAP conventions seen in the posted GRPOs
- 1 or 2 GRPOs per BDA invoice (SPO/VAC split). `DocDate` = posting date, 1–16 days after sailing.
- `DocDueDate` = `ShipDate` = sailing date (13 of 29 sea) or 1–7 days later; `U_ActShipDt` = same.
- `U_CartonNo` practice drifts (range 264, placeholder `1` 189, blank 41); Excel exports turn
  `1-2` into a date — write as text.
- Keying errors exist (`BDA46091099`, cartons 44 for 4, swapped CBM between a split pair); do not
  treat a single example as a rule.
