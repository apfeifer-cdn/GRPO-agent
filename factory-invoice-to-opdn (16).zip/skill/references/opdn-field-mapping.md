# OPDN / PDN1 field mapping

Verified against 72 posted GRPOs. "n/N" = agreement count in the examples. Columns not listed
follow `opdn-column-defaults.csv` (CONST from the template, NULL, or SYSTEM = left to SAP).

## OPDN_Header
| Column | Value | Source / note |
|---|---|---|
| DocEntry | 1, 2 | 2 only when SPO/VAC and other prefixes are both present (9/9) |
| DocDate, TaxDate | posting date | `--post-date`; SAP posted 1–16 days after sailing. Not the invoice date |
| DocDueDate | ship date | HBL on-board / flight date, else Mainland "Sailing on or about". = `U_ActShipDt` (SAP fills) |
| CardCode, CardName, Address | PO vendor | lookup `CardCode`/`CardName`; shipper on the invoice is Mainland Sewing (V00313 in examples), not Unimas |
| Address2 | `KS USA` | constant in all examples |
| NumAtCard, U_FactoryInv | `BDAnnnnnnnn` | Mainland invoice (72/72); never `EX/UNI/…` |
| Comments | `Based On Purchase Orders 120601. 120603.` | ascending, each followed by `.`; SAP truncates long lists (42/42 prefix match) |
| JrnlMemo | `Goods Receipt PO - <CardCode>` | |
| U_POPrefix | prefix of the lowest PO | 70/72 (also on multi-PO GRPOs; not NULL) |
| U_OrderNo | PO number | only when one PO on the GRPO |
| U_CustRefNo, U_SONo | from PO export | only when one PO; otherwise NULL |
| TrnspCode | 1 sea, 37 air | 71/72 |
| U_MOT | `40' HQ`, `20'`, `Air - Collect` | from HBL/PSA container size; `LOOKUP:container_size` without them |
| U_FOB | `Chittagong, Bangladesh` / `Dhaka, Bangladesh` | sea / air (70/72) |
| U_FCAAirport | `Dhaka, Bangladesh` | air only |
| U_OceanDest | `Kansas City, KS` | sea only |
| U_ShipVia | `Demotrans` / `AIR` | sea / air |
| U_Notify | `Bestway International` / `Bestway` / `FedEx Courier` | sea / air forwarder / courier |
| U_Carrier | `OCEAN NETWORK EXPRESS (NORTH AMERICA) INC`, airline name | from MBL prefix `ONEY` / flight prefix |
| U_COO, CountryOrg (line) | `BD` | Country of Origin on the invoice |
| U_TermSale | `FOB` | |
| U_MakerTerms | `CDN` | |
| U_NumCartons | Σ CTN of the GRPO's lines | 60/72; the rest are SAP keying errors |
| U_CubeMeters | Σ CBM, 2 dp | 67/72 |
| U_GrossWeight / U_DimWeight | air: Σ gross kg / Σ net kg (41/43); sea: representative per-carton G.W / N.W kg (REVIEW) | |
| Weight, Volume | NULL | SAP computes |
| U_ContREfNo | container (sea) / HAWB or tracking (air) | HBL, PSA |
| U_SealRefNo, U_BOLNo, U_MasterBLNo | seal, HBL `DML17275` (no hyphen), MBL `ONEY…` | sea only |
| U_AWB, U_MAWBNo | HAWB `DML15440` / tracking, MAWB digits | air only; final AWB values differ from the draft |
| U_VesselName | vessel without voyage (`ONE CYGNUS`), flight on air (`BA0295`) | |
| U_HandoverDate | NULL | Unimas ICD date matched 0/5 |
| U_FirstSaleTotal | Σ first-sale price × qty | 0 when no First Sales invoice |
| U_BLConsig, U_GenConsig | `Design Resources, Inc.` | |
| DocStatus/InvntSttus O, Printed/Posted N, Confirmed Y, CANCELED N | | new-document status |

Helper columns on `GRPO_Header` only: `_FactoryInv` (EX/UNI used), `_ShipTo`, `_Sources`.

## PDN1_Line
| Column | Value | Source / note |
|---|---|---|
| LineNum, VisOrder | 0.. per GRPO | lines ordered by PO number, then SEQ PI# (SAP order, 72/72) |
| BaseType, U_BaseType | 22 | |
| BaseRef, BaseDocNum | PO number | PO# digits |
| BaseEntry, BaseLine, U_BaseEntry, U_BaseLine | PO DocEntry / LineNum | lookup; `BaseEntry` = PO number in this DB |
| BaseCard | header CardCode | |
| ItemCode | SAP SKU from the lookup | packing style is `U_Proto`/C-number; stock SKUs are `SP500-INDI-OS` etc. Without lookup: packing item key |
| Dscription | PO line description | lookup; packing DESCRIPTION as fallback |
| Quantity, InvQty, PackQty, BaseQty | Σ pcs of the PO line's packing rows | 494/494 |
| Price, U_FOBPrice | PO line | lookup; `_InvoicePrice` holds the Mainland unit price for the cross-check |
| U_FirstSalePrice | First Sales invoice unit price | 0 when absent |
| LineTotal | qty × price | |
| Currency | `$` | |
| WhsCode | `2` | 494/494 |
| TrnsCode | = header TrnspCode | |
| ShipDate | = DocDueDate | |
| ActDelDate | = DocDate | |
| U_Color | PO line colour (lookup) | present on all SPO/VAC lines and on other POs that carry one (215/494); NULL on pure custom lines. Without lookup: packing colour on SPO/VAC only |
| U_LinePOPrefix | PO# prefix | |
| U_CustPO | customer ref | Unimas PO# token, or PO export `U_CustRefNo` |
| U_CartonNo | `62-63` or `62` (text) | min–max over merged rows |
| U_PcsPerCarton | full-carton pcs | 476/494 |
| U_NumfCart | Σ CTN | 484/494 |
| U_Packing | `3-144, 1-72` (text) | only for mixed packing |
| U_CartonWeight / Length / Width / Height | lb, in, in, in from G.W/CTN and cm dims | SAP history: 0 or a default carton; informational |
| FreeTxt | `PI BA1095333 seq 1; packing style C17-06417(SP500); color NAVY; cust ref 91690; mixed packing …` | |
| LineStatus, InvntSttus | O | |

Helper columns on `GRPO_Lines` only: `_Proto`, `_StyleRef` (paren text), `_InvoicePrice`,
`_PI`, `_SEQ`, `_PackGWkg`, `_PackCBM`.
